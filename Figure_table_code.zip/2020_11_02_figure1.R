### figure 1 combined
### a. study desgin
### b. illsurating fiugre
### c. boosting
### d. waning
### e. measurement error


## read the data here to get the date range for each range  

library(chron)

##################################################################################################################
# this is for panel A data
## use Jul 1, 2008 as baseline

###########################################
## read the raw data

setwd("/Users/timtsang/Dropbox/kiddivax/kiddivax raw data")


sero_y0 <- read.csv("/Users/timtsang/Dropbox/Shared kiddivax analysis/data/cumulative incidence data/2009 Kiddivax Pilot/2012_01_09_sero.csv",as.is=T)

sero_y1 <- read.csv("/Users/timtsang/Dropbox/Shared kiddivax analysis/data/cumulative incidence data/2010 Kiddivax Main/2012_12_04_serology.csv",as.is=T)

sero_y2 <- read.csv("/Users/timtsang/Dropbox/Shared kiddivax analysis/data/cumulative incidence data/2011 Kiddivax Follow Up/2012_09_20_serology.csv",as.is=T)

sero_y3 <- read.csv("/Users/timtsang/Dropbox/Shared kiddivax analysis/data/cumulative incidence data/2012 Kiddivax Follow Up/2013_08_23_serology.csv",as.is=T)

sero_y4 <- read.csv("/Users/timtsang/Dropbox/Shared kiddivax analysis/data/cumulative incidence data/2014 Kiddivax Follow Up/2016_07_12_kiddivax_yr4to5_serology.csv",as.is=T)



#R0
(min(dates(sero_y0$date.mids,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7
(max(dates(sero_y0$date.mids,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7


#R1
(min(dates(sero_y1$prevax,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7
(max(dates(sero_y1$prevax,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7

#R2
(min(dates(sero_y1$mid.season,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7
(max(dates(sero_y1$mid.season,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7

#R3
(min(dates(sero_y1$post.season,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7
(max(dates(sero_y1$post.season,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7

#R4
(min(dates(sero_y2$mid.season,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7
(max(dates(sero_y2$mid.season,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7 

#R5
(min(dates(sero_y2$post.season,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7
(max(dates(sero_y2$post.season,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7

#R6
(min(dates(sero_y3$mid.season,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7
(max(dates(sero_y3$mid.season,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7

#R7
(min(dates(sero_y3$post.season,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7
(max(dates(sero_y3$post.season,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7

#R8
(min(dates(sero_y4$date.y4.mid,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7
(max(dates(sero_y4$date.y4.mid,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7

#R9
(min(dates(sero_y4$date.y5.pre,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7
(max(dates(sero_y4$date.y5.pre,format="d/m/y"),na.rm=T) - dates("12/31/2008"))/7



proxy <- read.csv("/Users/timtsang/Dropbox/ILI_data/ILILAB_wei_2019.csv")

proxy$GPrate <- proxy$GPratePer1000/1000
proxy$H1N1.prox <- proxy$A.H1N1/proxy$Specimens.tested*proxy$GPrate
proxy$H3N2.prox <- proxy$A.H3N2/proxy$Specimens.tested*proxy$GPrate
proxy$H1N1pdm.prox <- proxy$A.H1N1pdm/proxy$Specimens.tested*proxy$GPrate
proxy$FluB.prox <- proxy$B/proxy$Specimens.tested*proxy$GPrate
proxy$index <- 1:nrow(proxy)

proxy <- proxy[10:261,]  # from May 2009
proxy$H3N2.prox[proxy$index>=261] <- 0  # set to zero to avoid confusion
proxy$H1N1pdm.prox[proxy$index>=261] <- 0
proxy$FluB.prox[proxy$index>=261] <- 0



#############

### panel B data

#load("/Users/timtsang/Dropbox/kiddivax/crossprotection/program_rcpp/realdata_v67/image_0.499201831175014.Rdata")

## input some demo here


### here create the data set to plot out 6 individuals, one from each epidemic


data1 <- data.frame(data1)

select <- c( 1758, 2401, 4616, 5310,7141,9035  )

plot1org <- plot1 <- data1[select,6:11]



############################################################################################################################################
# panel D,E data
waningdata <- tt[[1]][inc,20+0:7*2]
waninglist <- list(NA)

for (j in 1:8){
temp <- matrix(NA,10000,400)
  for (i in 1:10000){
  temp[i,1:400] <- exp(-waningdata[i,j]*1:400/365)  
  }  
waninglist[[j]] <- temp
}
waninglineCI <- matrix(NA,24,400)
for (i in 1:400){
for (j in 1:8){
  waninglineCI[1+3*(j-1),i] <- mean(waninglist[[j]][,i]) 
  waninglineCI[2:3+3*(j-1),i] <- quantile(waninglist[[j]][,i],c(0.025,0.975))  
}  
}

overallwan <- waninglist[[3]][,365]
for (j in 4:6){
overallwan <- c(overallwan, waninglist[[j]][,365])  
}
mean(overallwan)
quantile(overallwan,c(0.025,0.975))

overallwan <- waninglist[[7]][,365]
for (j in 8){
  overallwan <- c(overallwan, waninglist[[j]][,365])  
}
mean(overallwan)
quantile(overallwan,c(0.025,0.975))

pdf("/Users/timtsang/SPH Dropbox/Tim Tsang/kiddivax/crossprotection/summary/2020_11_01_figure1.pdf",width=12, height=7)
layout(matrix(c(rep(1,12),rep(2,12),rep(3,10),rep(4,7),rep(5,7)),nrow=2,byrow=T))

####################################################################################################################
## 1a
par(mar=c(2,5,0,0))
plot(NA,xlim=c(10,263),ylim=c(0,0.078),ylab="",xlab="",axes=F)

polygon(proxy$index[c(1,1:nrow(proxy),nrow(proxy),1)],c(0,proxy$H3N2.prox,0,0),
        col=rgb(0,0,0.9,0.5),border=F)  
polygon(proxy$index[c(1,1:nrow(proxy),nrow(proxy),1)],
        c(0,proxy$H1N1pdm.prox,0,0),col=rgb(1,0,0,0.5),border=F)
#polygon(proxy$index[c(1,1:nrow(proxy),nrow(proxy),1)],
#        c(0,proxy$FluB.prox,0,0),col=rgb(0,0.9,0,0.5),border=F)

axis(1,at=c(10,cumsum(table(proxy$Year))+9),labels=NA,tck=0)
axis(1,at=cumsum(table(proxy$Year))[1:6]+9,labels=NA)
mtext(2009,side=1,at=29,line=0.5)
for(i in 1:4){mtext(2009+i,side=1,at=cumsum(table(proxy$Year))[i]+9+26,line=0.5)}
axis(2,at=0:7*0.01,las=1)

legend(150,0.07,legend=c(
  "Seasonal influenza A(H3N2)","Pandemic influenza A(H1N1)pdm09"),
  fill=c(rgb(0,0,0.9,0.5),
         rgb(1,0,0,0.5)),border=NA,bty="n")

# add study timeline
set1 <- 0.005
set2 <- 0.078

lines(c(13,13,17,17),c(0.0785,0.08,0.08,0.0785)-set1)
text((13+17)/2,set2,"R1",cex=1)

lines(c(34,34,59,59),c(0.0785,0.08,0.08,0.0785)-set1)
text((34+59)/2,set2,"R2",cex=1)

lines(c(67,67,71,71),c(0.0785,0.08,0.08,0.0785)-set1)
text((67+71)/2,set2,"R3",cex=1)

lines(c(81,81,101,101),c(0.0785,0.08,0.08,0.0785)-set1)
text((81+101)/2,set2,"R4",cex=1)

lines(c(119,119,124,124),c(0.0785,0.08,0.08,0.0785)-set1)
text((119+124)/2,set2,"R5",cex=1)

lines(c(143,143,153,153),c(0.0785,0.08,0.08,0.0785)-set1)
text((143+153)/2,set2,"R6",cex=1)

lines(c(173,173,176,176),c(0.0785,0.08,0.08,0.0785)-set1)
text((173+176)/2,set2,"R7",cex=1)

lines(c(196,196,204,204),c(0.0785,0.08,0.08,0.0785)-set1)
text((196+204)/2,set2,"R8",cex=1)

lines(c(225,225,228,228),c(0.0785,0.08,0.08,0.0785)-set1)
text((225+228)/2,set2,"R9",cex=1)

lines(c(250,250,257,257),c(0.0785,0.08,0.08,0.0785)-set1)
text((250+257)/2,set2,"R10",cex=1)

title(main="A", adj=0,line=-1.5)

points(c(39,90,109,178,219,246),c(0.071,0.023,0.023,0.029,0.007,0.009),pch=1,cex=2.5)  # circle
points(c(39,90,109,178,219,246),c(0.071,0.023,0.023,0.029,0.007,0.009),pch=c("1","2","3","4","5","6"),
       cex=1)  # number

mtext("Influenza activity",side=2,line=3.5)

####################################################################################################################
## 1b

par(mar=c(4,2,2,0))

i <- 111

xlim <-   ceiling((data1[i,5]-data1[i,4])/100)*100

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,1400), ylim=c(0,6),type="n")

#axis(1,at=0:(xlim/100)*100,c(0,NA,200,NA,400,NA,600),cex.axis=1)
#axis(2,at=0:6, las=1, pos=-10)
#axis(4,at=0:6, las=1, labels = c("<10",5*2^(1:6)), pos=1400)

axis(2,at=0:6, las=1, labels = c("<10",5*2^(1:6)), pos=-10)

adjust <- 0
adjust2 <- 400/600
#plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,1200), ylim=c(0,6),type="n")

axis(1,at=adjust+0:(xlim/100)*100*adjust2,labels = c(0,NA,200,NA,400,NA,600),cex.axis=1)
#axis(2,at=0:6, las=1, pos=-10)

points(adjust+(data1[i,6:8]-data1[i,6])*adjust2,data1[i,9:11],pch=16,col="black")


## here get the line

for (k in  sample(1:10000,100)){
  value <- c(tt[[13]][k,i],tt[[14]][k,i],tt[[15]][k,i],tt[[16]][k,i],tt[[17]][k,i])
  if (value[1]==1){
    ## first line before infection
    vec1 <- 0:(value[2]-data1[i,6]-14)
    vec2 <- value[5]*exp(-(vec1)/365*value[3])
    lines(adjust+vec1*adjust2,vec2,col=rgb(1,0,0,0.15))  
    ## second line at infection
    startpt <- vec2[length(vec2)]
    endpt <- vec2[length(vec2)]+value[4]
    lines(adjust+(c(value[2]-14,value[2])-data1[i,6])*adjust2,c(startpt,endpt),col=rgb(1,0,0,0.15))
    ## last line
    vec1 <- value[2]:data1[i,5]-value[2]
    vec2 <- endpt*exp(-(vec1)/365*value[3])  
    lines(adjust+(c(value[2]:data1[i,5])-data1[i,6])*adjust2,vec2,col=rgb(1,0,0,0.15))
    
  }
  if (value[1]==0){
    vec1 <- 0:(data1[i,5]-data1[i,6])
    vec2 <- value[5]*exp(-(vec1)/365*value[3])
    lines(adjust+vec1*adjust2,vec2,col=rgb(0,0,1,0.15))  
  }
}



mtext("Antibody titer",side=2,line=1.5)

#mtext(expression(paste("log"[2]," titer")),side=2,line=1.5)
#mtext(expression("Linear titer"),side=4,line=1.5)
#mtext("pH1",side=1,line=2.5,at=1.5)
#mtext("sH3",side=1,line=2.5,at=4.5)


legend(150,5.6,c("Observed titer","Trajectories with infection","Trajectories without infection"),col=c("black","red","blue"),cex=0.9,bty="n",lty=c(NA,1,1),pch=c(16,NA,NA))

mean(tt[[13]][,i])
text(150,5.8,paste("P(infection)=","0.81",sep=""),cex=1,pos=4)
mtext("Child 1 in epidemic 1",side=3,line=0.25,at=200)

title(main="B", adj=0)

mtext("Days since start of follow up",side=1,line=2.5)





i <- 237
xlim <-   ceiling((data1[i,5]-data1[i,4])/100)*100
adjust <- 500
adjust2 <- 400/600
#plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,1200), ylim=c(0,6),type="n")

axis(1,at=adjust+0:(xlim/100)*100*adjust2,labels = c(0,NA,200,NA,400,NA,600),cex.axis=1)
#axis(2,at=0:6, las=1, pos=-10)

points(adjust+(data1[i,6:8]-data1[i,6])*adjust2,data1[i,9:11],pch=16,col="black")


## here get the line

for (k in  sample(1:10000,100)){
  value <- c(tt[[13]][k,i],tt[[14]][k,i],tt[[15]][k,i],tt[[16]][k,i],tt[[17]][k,i])
  if (value[1]==1){
    ## first line before infection
    vec1 <- 0:(value[2]-data1[i,6]-14)
    vec2 <- value[5]*exp(-(vec1)/365*value[3])
    lines(adjust+vec1*adjust2,vec2,col=rgb(1,0,0,0.15))  
    ## second line at infection
    startpt <- vec2[length(vec2)]
    endpt <- vec2[length(vec2)]+value[4]
    lines(adjust+(c(value[2]-14,value[2])-data1[i,6])*adjust2,c(startpt,endpt),col=rgb(1,0,0,0.15))
    ## last line
    vec1 <- value[2]:data1[i,5]-value[2]
    vec2 <- endpt*exp(-(vec1)/365*value[3])  
    lines(adjust+(c(value[2]:data1[i,5])-data1[i,6])*adjust2,vec2,col=rgb(1,0,0,0.15))
    
  }
  if (value[1]==0){
    vec1 <- 0:(data1[i,5]-data1[i,6])
    vec2 <- value[5]*exp(-(vec1)/365*value[3])
    lines(adjust+vec1*adjust2,vec2,col=rgb(0,0,1,0.15))  
  }
}


#mtext(expression(paste("log"[2]," titer")),side=2,line=2)

#mtext("pH1",side=1,line=2.5,at=1.5)
#mtext("sH3",side=1,line=2.5,at=4.5)


mean(tt[[13]][,i])
text(adjust+0,5.8,paste("P(infection)=","0.80",sep=""),cex=1,pos=4)
mtext("Adult 1 in epidemic 1",side=3,line=0.25,at=adjust+200)

#title(main="A", adj=0)

#mtext("Days since start of the epidemic",side=1,line=2.5)



i <- 6995-5
xlim <-   ceiling((data1[i,5]-data1[i,4])/100)*100
adjust <- 1000

#plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,1200), ylim=c(0,6),type="n")

axis(1,at=adjust+0:(xlim/100)*100,labels = c(0,NA,200,NA,400),cex.axis=1)
#axis(2,at=0:6, las=1, pos=-10)

points(adjust+data1[i,6:8]-data1[i,6],data1[i,9:11],pch=16,col="black")


## here get the line

for (k in  sample(1:10000,100)){
  value <- c(tt[[13]][k,i],tt[[14]][k,i],tt[[15]][k,i],tt[[16]][k,i],tt[[17]][k,i])
  if (value[1]==1){
    ## first line before infection
    vec1 <- 0:(value[2]-data1[i,6]-14)
    vec2 <- value[5]*exp(-(vec1)/365*value[3])
    lines(adjust+vec1,vec2,col=rgb(1,0,0,0.15))  
    ## second line at infection
    startpt <- vec2[length(vec2)]
    endpt <- vec2[length(vec2)]+value[4]
    lines(adjust+c(value[2]-14,value[2])-data1[i,6],c(startpt,endpt),col=rgb(1,0,0,0.15))
    ## last line
    vec1 <- value[2]:data1[i,5]-value[2]
    vec2 <- endpt*exp(-(vec1)/365*value[3])  
    lines(adjust+c(value[2]:data1[i,5])-data1[i,6],vec2,col=rgb(1,0,0,0.15))
    
  }
  if (value[1]==0){
    vec1 <- 0:(data1[i,5]-data1[i,6])
    vec2 <- value[5]*exp(-(vec1)/365*value[3])
    lines(adjust+vec1,vec2,col=rgb(0,0,1,0.15))  
  }
}


#mtext(expression(paste("log"[2]," titer")),side=2,line=2)

#mtext("pH1",side=1,line=2.5,at=1.5)
#mtext("sH3",side=1,line=2.5,at=4.5)


#legend(0,5,c("Observed titer","Trajectories with Infection","Trajectories without Non-infection"),col=c("black","red","blue"),cex=0.9,bty="n",lty=c(NA,1,1),pch=c(16,NA,NA))

mean(tt[[13]][,i])
text(adjust+0,5.8,paste("P(infection)=","0.08",sep=""),cex=1,pos=4)
mtext("Adult 2 in epidemic 5",side=3,line=0.25,at=adjust+200)

#title(main="A", adj=0)

#mtext("Days since start of the epidemic",side=1,line=2.5)



############################################################################################################################################
## panel C
par(mar=c(2,3.5,2,0))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,8.5), ylim=c(0,11),type="n")

adjust <- 4.5
axis(1,at=c(0,1,3,4),labels=c(NA,"Children","Adults",NA),cex.axis=1,lwd.ticks = 0)
axis(1,at=c(1,3),labels=c(NA),cex.axis=1)

axis(1,at=adjust+c(0,1,3,4),labels=c(NA,"Children","Adults",NA),cex.axis=1,lwd.ticks = 0)
axis(1,at=adjust+c(1,3),labels=c(NA),cex.axis=1)
#axis(1,at=c(0,1,3,4)+adjust,labels=c(NA,"Children","Adults",NA),cex.axis=1)

axis(2,at=0:5*2, las=1, pos=-0.05)

# vioplot

### h1n1 strain change for children
xvec <- 1:100/10
yvec <- dgamma(1:100/10,z1[19,1],1)
polygon( c(yvec,rev(rep(0,length(yvec))))+0.5 ,c(xvec,rev(xvec)),col=rgb(1,0,0,0.1),border=NA)
polygon( -c(yvec,rev(rep(0,length(yvec))))+0.5 ,c(xvec,rev(xvec)),col=rgb(1,0,0,0.1),border=NA)

### h1n1 strain change for adults
xvec <- 1:100/10
yvec <- dgamma(1:100/10,z1[21,1],1)
polygon( c(yvec,rev(rep(0,length(yvec))))+2.5 ,c(xvec,rev(xvec)),col=rgb(1,0,0,0.1),border=NA)
polygon( -c(yvec,rev(rep(0,length(yvec))))+2.5 ,c(xvec,rev(xvec)),col=rgb(1,0,0,0.1),border=NA)


### h1n1 no strain change for children
xvec <- 1:100/10
yvec <- dgamma(1:100/10,z1[23,1],1)
polygon( c(yvec,rev(rep(0,length(yvec))))+1.5 ,c(xvec,rev(xvec)),col=rgb(0,0,1,0.1),border=NA)
polygon( -c(yvec,rev(rep(0,length(yvec))))+1.5 ,c(xvec,rev(xvec)),col=rgb(0,0,1,0.1),border=NA)

### h1n1 no strain change for adults
xvec <- 1:100/10
yvec <- dgamma(1:100/10,z1[25,1],1)
polygon( c(yvec,rev(rep(0,length(yvec))))+3.5 ,c(xvec,rev(xvec)),col=rgb(0,0,1,0.1),border=NA)
polygon( -c(yvec,rev(rep(0,length(yvec))))+3.5 ,c(xvec,rev(xvec)),col=rgb(0,0,1,0.1),border=NA)


### h3n2 strain change for children
xvec <- 1:100/10
yvec <- dgamma(1:100/10,z1[27,1],1)
polygon( c(yvec,rev(rep(0,length(yvec))))+0.5+adjust ,c(xvec,rev(xvec)),col=rgb(1,0.63,0,0.1),border=NA)
polygon( -c(yvec,rev(rep(0,length(yvec))))+0.5+adjust ,c(xvec,rev(xvec)),col=rgb(1,0.63,0,0.1),border=NA)

### h3n2 strain change for adults
xvec <- 1:100/10
yvec <- dgamma(1:100/10,z1[29,1],1)
polygon( c(yvec,rev(rep(0,length(yvec))))+2.5+adjust ,c(xvec,rev(xvec)),col=rgb(1,0.63,0,0.1),border=NA)
polygon( -c(yvec,rev(rep(0,length(yvec))))+2.5+adjust ,c(xvec,rev(xvec)),col=rgb(1,0.63,0,0.1),border=NA)


### h3n2 no strain change for children
xvec <- 1:100/10
yvec <- dgamma(1:100/10,z1[31,1],1)
polygon( c(yvec,rev(rep(0,length(yvec))))+1.5+adjust ,c(xvec,rev(xvec)),col=rgb(0.5,0,0.5,0.1),border=NA)
polygon( -c(yvec,rev(rep(0,length(yvec))))+1.5+adjust ,c(xvec,rev(xvec)),col=rgb(0.5,0,0.5,0.1),border=NA)

### h3n2 no strain change for adults
xvec <- 1:100/10
yvec <- dgamma(1:100/10,z1[33,1],1)
polygon( c(yvec,rev(rep(0,length(yvec))))+3.5+adjust ,c(xvec,rev(xvec)),col=rgb(0.5,0,0.5,0.1),border=NA)
polygon( -c(yvec,rev(rep(0,length(yvec))))+3.5+adjust ,c(xvec,rev(xvec)),col=rgb(0.5,0,0.5,0.1),border=NA)



#points(0:1+0.4,mcmc[c(19,21),2],pch=16,col="red")
#points(0:1+0.6,mcmc[c(27,29),2],pch=17,col="blue")


for (i in 0:1){
  lines(0.5+2*i+c(-0.3,0.3),rep(z1[19+2*i,1],2),col="red",lty=1)
  #lines(0.5+2*i+c(-0.3,0.3),rep(z1[19+2*i,2],2),col="red",lty=1)
  #lines(0.5+2*i+c(-0.3,0.3),rep(z1[19+2*i,3],2),col="red",lty=1)
  lines(rep(0.5+2*i,2),z1[19+2*i,2:3],col="red",lty=1)
  
  lines(1.5+2*i+c(-0.3,0.3),rep(z1[23+2*i,1],2),col="blue",lty=1)
  #lines(1.5+2*i+c(-0.3,0.3),rep(z1[27+2*i,2],2),col="blue",lty=1)
  #lines(1.5+2*i+c(-0.3,0.3),rep(z1[27+2*i,3],2),col="blue",lty=1)
  lines(rep(1.5+2*i,2),z1[23+2*i,2:3],col="blue",lty=1)
  
  lines(0.5+2*i+c(-0.3,0.3)+adjust,rep(z1[27+2*i,1],2),col="orange",lty=1)
  #lines(0.5+2*i+c(-0.3,0.3)+adjust,rep(z1[31+2*i,2],2),col="red",lty=1)
  #lines(0.5+2*i+c(-0.3,0.3)+adjust,rep(z1[31+2*i,3],2),col="red",lty=1)
  lines(rep(0.5+2*i,2)+adjust,z1[27+2*i,2:3],col="orange",lty=1)
  
  lines(1.5+2*i+c(-0.3,0.3)+adjust,rep(z1[31+2*i,1],2),col="purple",lty=1)
  #lines(1.5+2*i+c(-0.3,0.3)+adjust,rep(z1[23+2*i,2],2),col="blue",lty=1)
  #lines(1.5+2*i+c(-0.3,0.3)+adjust,rep(z1[23+2*i,3],2),col="blue",lty=1)
  lines(rep(1.5+2*i,2)+adjust,z1[31+2*i,2:3],col="purple",lty=1)
  
}


legend(0,11.3,c("Epidemic 1 (with strain change)","Epidemic 3/5 (no strain change)"),lty=1,cex=1.1,bty="n",col=c("red","blue"))
legend(0+adjust-0.1,11.3,c("Epidemic 4 (with strain change)","Epidemic 2/6 (no strain change)"),lty=1,cex=1.1,bty="n",col=c("orange","purple"))

#mtext(expression(paste("Fold rise in log"[2]," titer")), side=2, line=1.75,cex=1)

mtext("Fold rise in antibody titer", side=2, line=1.75,cex=1)

mtext("H1N1",side=3,line=0.5,at=2)
mtext("H3N2",side=3,line=0.5,at=2+adjust)
title(main="C", adj=0)

############################################################################################################################################
## panel D
par(mar=c(4,5,2,0))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,400), ylim=c(0.3,1),type="n")


axis(1,at=0:4*100,labels=c(0,NA,200,NA,400),cex.axis=1)

axis(2,at=3:10/10, labels = c("30%","40%","50%","60%","70%","80%","90%","100%"), las=1, pos=-0.05)

xvec <- 1:400
polygon( c(xvec,rev(xvec)), c((waninglineCI[2,]),rev(waninglineCI[3,])),col=rgb(1,0,0,0.1),border=NA)
lines(xvec,waninglineCI[1,],col="red")

polygon( c(xvec,rev(xvec)), c((waninglineCI[5,]),rev(waninglineCI[6,])),col=rgb(0,0,1,0.1),border=NA)
lines(xvec,waninglineCI[4,],col="blue")

polygon( c(xvec,rev(xvec)), c((waninglineCI[8,]),rev(waninglineCI[9,])),col=rgb(1,0.63,0,0.1),border=NA)
lines(xvec,waninglineCI[7,],col="orange")

polygon( c(xvec,rev(xvec)), c((waninglineCI[11,]),rev(waninglineCI[12,])),col=rgb(0.5,0,0.5,0.1),border=NA)
lines(xvec,waninglineCI[10,],col="purple")

legend(0,0.5,c("Children with strain change (Epidemic 1)","Adults with strain change (Epidemic 1)",
               "Children without strain change (Epidemic 3/5)","Adults without strain change (Epidemic 3/5)"),lty=1,cex=1,bty="n",col=c("red","blue","orange","purple"))

mtext("Change in antibody", side=2, line=2.5,cex=1)

mtext("H1N1",side=3,line=0.5)
#mtext("H1N1",side=3,line=0.5,at=2)
#mtext("H3N2",side=3,line=0.5,at=2+adjust)
title(main="D", adj=0)
mtext("Days since boosting",side=1,line=2.5)


############################################################################################################################################
## panel D
par(mar=c(4,5,2,0))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,400), ylim=c(0.6,1),type="n")


axis(1,at=0:4*100,labels=c(0,NA,200,NA,400),cex.axis=1)

axis(2,at=6:10/10, labels = c("60%","70%","80%","90%","100%"), las=1, pos=-0.05)

xvec <- 1:400
polygon( c(xvec,rev(xvec)), c((waninglineCI[2+12,]),rev(waninglineCI[3+12,])),col=rgb(1,0,0,0.1),border=NA)
lines(xvec,waninglineCI[1+12,],col="red")

polygon( c(xvec,rev(xvec)), c((waninglineCI[5+12,]),rev(waninglineCI[6+12,])),col=rgb(0,0,1,0.1),border=NA)
lines(xvec,waninglineCI[4+12,],col="blue")

polygon( c(xvec,rev(xvec)), c((waninglineCI[8+12,]),rev(waninglineCI[9+12,])),col=rgb(1,0.63,0,0.1),border=NA)
lines(xvec,waninglineCI[7+12,],col="orange")

polygon( c(xvec,rev(xvec)), c((waninglineCI[11+12,]),rev(waninglineCI[12+12,])),col=rgb(0.5,0,0.5,0.1),border=NA)
lines(xvec,waninglineCI[10+12,],col="purple")

legend(0,0.7,c("Children with strain change (Epidemic 4)","Adults with strain change (Epidemic 4)",
               "Children without strain change (Epidemic 2/6)","Adults without strain change (Epidemic 2/6)"),lty=1,cex=1,bty="n",col=c("red","blue","orange","purple"))


mtext("Change in antibody", side=2, line=2.5,cex=1)

mtext("H3N2",side=3,line=0.5)
#mtext("H3N2",side=3,line=0.5,at=2+adjust)
#title(main="D", adj=0)
mtext("Days since boosting",side=1,line=2.5)

dev.off()

############################################################################################################################################
## panel E
## panel E data

textcex <- 1.2
error <- z1[1:3,]
error[1,] <- error[1,]*10
error[2:3,] <- 0.25/exp(error[2:3,])

par(mar=c(4.5,4.5,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,3), ylim=c(0,0.06),type="n")


axis(1,at=c(-1,0.5,1.5,2.5,4),labels=NA,cex.axis=1,cex=textcex)

axis(2,at=0:3*0.02, las=1, pos=-0.05,cex=textcex)

points(0.5+0:2,error[,1],pch=16:18,cex=2)
for (i in 0:2){
  lines(rep(0.5+i,2),error[i+1,2:3],lwd=2)  
}

#legend(0,0.2,c("Pandemic (Epidemic 1)","Seasonal (Epidemic 2-6)"),lty=1,cex=0.8,bty="n",col=c("red","blue"))

mtext("Probability", side=2, line=2.5,cex=textcex)

mtext("Random error",side=1,line=1,at=0.5,cex=textcex)
mtext("H1N1",side=1,line=1,at=1.5,cex=textcex)
mtext("H3N2",side=1,line=1,at=2.5,cex=textcex)
mtext("Two-fold error",side=1,line=2.5,at=2,cex=textcex)
title(main="E", adj=0)



dev.off()