
setwd("/Users/timtsang/Dropbox/kiddivax/crossprotection/program_rcpp/realdata_v67_sim")

rawlist <- list.files(pattern="*.csv")
rawlist1 <- rawlist[grepl("summary_",rawlist)]
rawlist2 <- rawlist[grepl("summary2_",rawlist)]

int_para <-  c(0.2,
               3.5,3.0,
               1,1.5,
               3.5,3.0,
               1,1.5,
               1,1,1,1,
               1,1,1,1,
               0.25,0.1,0.1,0.4,0.2,0.2,
               0.4,0.2,0.2,
               0.4,0.2,0.2,
               0.4,0.2,0.2,
               0.4,0.2,0.2,
               0.4,0.2,0.2)


# children, adults
int_para2 <- c(0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005)  

int_para <- as.vector(as.matrix(read.csv("para1.csv")[,2]))
int_para2 <- as.vector(as.matrix(read.csv("para2.csv")[,2]))

for (i in 1:12){
  int_para2[10*(i-1)+1] <- 1- sum(int_para2[10*(i-1)+2:10])
}


nsim <- 50
tt1 <- tt2 <- matrix(NA,nsim,length(int_para))
tt12 <- tt22 <- matrix(NA,nsim,length(int_para2))

for (i in 1:nsim){
temp <- read.csv(rawlist1[i])  
tt1[i,] <- temp[,2]
tt2[i,] <- 1*(temp[,3] <= int_para & temp[,4] >= int_para)

temp <- read.csv(rawlist2[i])  
tt12[i,] <- temp[,2]
tt22[i,] <- 1*(temp[,3] <= int_para2 & temp[,4] >= int_para2)
}

summary(tt1)
summary(tt2)


orderlist <- c(43:48,49:51,66,52:54,68,55:57,70,58:60,72,61:63,74,19:34,2:3,1)
out <- matrix(NA,45,3)
out[,1] <- int_para[orderlist ]
out[,2] <- colMeans(tt1)[orderlist ]
out[,3] <- colMeans(tt2)[orderlist ]

out[1:44,] <- round(out[1:44,],2)
out[45,] <- round(out[45,],4)

write.csv(out,"/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/tableS3.csv")