## this is the panel b for the sens and spec for our algorithm
## generate data to plot figure 4A and model adeq
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}



setwd("/Users/timtsang/Dropbox/kiddivax/crossprotection/program_rcpp/realdata_v67_sim")

rawlist <- list.files(pattern="*.csv")
rawlist1 <- rawlist[grepl("summary_",rawlist)]
rawlist2 <- rawlist[grepl("summary2_",rawlist)]

rawlist5 <- rawlist[grepl("input1_",rawlist)]
rawlist4 <- rawlist[grepl("input2_",rawlist)]
rawlist3 <- rawlist[grepl("input3_",rawlist)]

rawlistr <- list.files(pattern="*.Rdata")


data <- read.csv("/Users/timtsang/Dropbox/kiddivax/crossprotection/program_rcpp/realdata_v67_sim/input2_0.584066709969193.csv")

missbase <- data[,10]==-1
missmid <- data[,12]==-1


nsim <- 50

problist <- twofoldlist <- fourfoldlist <- eightfoldlist <- matrix(NA,50,12)

seasonlist <- list(c(0,1,2,3,4,5))

probadeq1 <- matrix(NA,50,11)
probadeqvec1 <- c(-1,0.2,1,2,3,4,5,6,7,8,9,10)/10

# 1,2 season
# 3,4 with or without baseline
# 4 with mid ot without mide

for (i in 1:nsim){
  load(rawlistr[[i]])
  
  temp <- read.csv(rawlist3[i])  
  
  temp2 <- read.csv(rawlist4[i])
  
  temp3 <- read.csv(rawlist5[i])
  
  temp$twofold <- 1*((temp2[,11]-temp2[,10]>=1&temp2[,11]!=-1&temp2[,10]!=-1)|(temp2[,12]-temp2[,11]>=1&temp2[,12]!=-1&temp2[,11]!=-1))
  temp$fourfold <- 1*((temp2[,11]-temp2[,10]>=2&temp2[,11]!=-1&temp2[,10]!=-1)|(temp2[,12]-temp2[,11]>=2&temp2[,12]!=-1&temp2[,11]!=-1))
  temp$eightfold <- 1*((temp2[,11]-temp2[,10]>=3&temp2[,11]!=-1&temp2[,10]!=-1)|(temp2[,12]-temp2[,11]>=3&temp2[,12]!=-1&temp2[,11]!=-1))
  
  eightfoldlist[i,1] <- mean(temp$eightfold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==1])
  eightfoldlist[i,2] <- 1-mean(temp$eightfold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==1])
  eightfoldlist[i,3] <- mean(temp$eightfold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==0]) 
  eightfoldlist[i,4] <- 1-mean(temp$eightfold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==0])
  eightfoldlist[i,5] <- mean(temp$eightfold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==1])
  eightfoldlist[i,6] <- 1-mean(temp$eightfold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==1])
  eightfoldlist[i,7] <- mean(temp$eightfold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==0]) 
  eightfoldlist[i,8] <- 1-mean(temp$eightfold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==0])
  eightfoldlist[i,9] <- mean(temp$eightfold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==1])
  eightfoldlist[i,10] <- 1-mean(temp$eightfold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==1])
  eightfoldlist[i,11] <- mean(temp$eightfold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==0]) 
  eightfoldlist[i,12] <- 1-mean(temp$eightfold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==0])
  
  fourfoldlist[i,1] <- mean(temp$fourfold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==1])
  fourfoldlist[i,2] <- 1-mean(temp$fourfold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==1])
  fourfoldlist[i,3] <- mean(temp$fourfold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==0]) 
  fourfoldlist[i,4] <- 1-mean(temp$fourfold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==0])
  fourfoldlist[i,5] <- mean(temp$fourfold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==1])
  fourfoldlist[i,6] <- 1-mean(temp$fourfold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==1])
  fourfoldlist[i,7] <- mean(temp$fourfold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==0]) 
  fourfoldlist[i,8] <- 1-mean(temp$fourfold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==0])
  fourfoldlist[i,9] <- mean(temp$fourfold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==1])
  fourfoldlist[i,10] <- 1-mean(temp$fourfold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==1])
  fourfoldlist[i,11] <- mean(temp$fourfold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==0]) 
  fourfoldlist[i,12] <- 1-mean(temp$fourfold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==0])
  
  twofoldlist[i,1] <- mean(temp$twofold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==1])
  twofoldlist[i,2] <- 1-mean(temp$twofold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==1])
  twofoldlist[i,3] <- mean(temp$twofold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==0]) 
  twofoldlist[i,4] <- 1-mean(temp$twofold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==0])
  twofoldlist[i,5] <- mean(temp$twofold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==1])
  twofoldlist[i,6] <- 1-mean(temp$twofold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==1])
  twofoldlist[i,7] <- mean(temp$twofold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==0]) 
  twofoldlist[i,8] <- 1-mean(temp$twofold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==0])
  twofoldlist[i,9] <- mean(temp$twofold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==1])
  twofoldlist[i,10] <- 1-mean(temp$twofold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==1])
  twofoldlist[i,11] <- mean(temp$twofold[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==0]) 
  twofoldlist[i,12] <- 1-mean(temp$twofold[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==0])
  
  temp$probability <- colMeans((a1))
  temp$prob <- 1*(temp$probability>0.5)

  problist[i,1] <- mean(temp$prob[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==1])
  problist[i,2] <- 1-mean(temp$prob[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==1])
  problist[i,3] <- mean(temp$prob[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==0]) 
  problist[i,4] <- 1-mean(temp$prob[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==1&missmid==0])
  problist[i,5] <- mean(temp$prob[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==1])
  problist[i,6] <- 1-mean(temp$prob[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==1])
  problist[i,7] <- mean(temp$prob[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==0]) 
  problist[i,8] <- 1-mean(temp$prob[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==0&missmid==0])
  problist[i,9] <- mean(temp$prob[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==1])
  problist[i,10] <- 1-mean(temp$prob[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==1])
  problist[i,11] <- mean(temp$prob[temp$V4==1&temp2[,13]%in%seasonlist[[1]]&missbase==0]) 
  problist[i,12] <- 1-mean(temp$prob[temp$V4==0&temp2[,13]%in%seasonlist[[1]]&missbase==0])
  
  for (j in 2:length(probadeqvec1)-1){
  probadeq1[i,j] <- mean( temp$V4[temp$probability>probadeqvec1[j]&temp$probability<=probadeqvec1[j+1]] )
  }
  
  print(i)
}  


z1 <- para_summary(probadeq1,4,3,0)
z2 <- para_summary(twofoldlist,4,3,0)
z3 <- para_summary(fourfoldlist,4,3,0)
z4 <- para_summary(eightfoldlist,4,3,0)
z5 <- para_summary(problist,4,3,0)

write.csv(rbind(z3,z5),"/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/sen_spec_data.csv")
write.csv(z1,"/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/modeladeq.csv")

