## this is the panel c(new panel b)
## for the true risk, by 4-fold rise or by algorithm


## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}



setwd("/Users/timtsang/Dropbox/kiddivax/crossprotection/program_rcpp/realdata_v67_sim")


ILI <- read.csv("/Users/timtsang/Dropbox/kiddivax/crossprotection/program_rcpp/realdata_v67/ILILAB_2019_04_25.csv")

rawlist <- list.files(pattern="*.csv")
rawlist1 <- rawlist[grepl("summary_",rawlist)]
rawlist2 <- rawlist[grepl("summary2_",rawlist)]

rawlist5 <- rawlist[grepl("input1_",rawlist)]
rawlist4 <- rawlist[grepl("input2_",rawlist)]
rawlist3 <- rawlist[grepl("input3_",rawlist)]

rawlistr <- list.files(pattern="*.Rdata")

data <- read.csv("/Users/timtsang/Dropbox/kiddivax/crossprotection/program_rcpp/realdata_v67_sim/input2_0.584066709969193.csv")

missbase <- data[,10]==-1
missmid <- data[,12]==-1


nsim <- 50

reallist <- matrix(NA,50,30)
fourfoldlist <- matrix(NA,50,30)

seasonlist <- list(c(0,1,2,3,4,5))

probadeq1 <- matrix(NA,50,11)
probadeqvec1 <- c(-1,0.2,1,2,3,4,5,6,7,8,9,10)/10

## get the sim para

int_para <- as.vector(as.matrix(read.csv("para1.csv"))[,2])
int_para2 <- as.vector(as.matrix(read.csv("para2.csv"))[,2])

## get the plot matrix for risk
truerisk <- matrix(NA,6,5)

truerisk[1,1] <- 1-exp(-(int_para[43]*sum(ILI[552:670,1])+int_para[46]*sum(ILI[671:747,1])))
truerisk[1,2] <- 1-exp(-(int_para[44]*sum(ILI[552:670,1])+int_para[47]*sum(ILI[671:747,1])))
truerisk[1,3] <- 1-exp(-(int_para[45]*sum(ILI[552:670,1])+int_para[48]*sum(ILI[671:747,1])))


indrow <- list(552:747,944:1020,1105:1153,1532:1636,1875:1937,2022:2112)

for (u in 2:6){
  truerisk[u,1]<- 1-exp(-(int_para[43+3*u]*sum(ILI[indrow[[u]],2-u%%2])))
  truerisk[u,2] <- 1-exp(-(int_para[44+3*u]*sum(ILI[indrow[[u]],2-u%%2])))
  truerisk[u,3]<- 1-exp(-(int_para[45+3*u]*sum(ILI[indrow[[u]],2-u%%2])))
}

truerisk[,4] <- truerisk[,1]/truerisk[,2]
truerisk[,5] <- truerisk[,3]/truerisk[,2]

for (i in 1:nsim){
#  load(rawlistr[[i]])
  
  temp <- read.csv(rawlist1[i])  
  
  temp2 <- read.csv(rawlist4[i])
  para <- temp[,2]
#  temp3 <- read.csv(rawlist5[i])
  
  reallist[i,1] <- 1-exp(-(para[43]*sum(ILI[552:670,1])+para[46]*sum(ILI[671:747,1])))
  reallist[i,1+6] <- 1-exp(-(para[44]*sum(ILI[552:670,1])+para[47]*sum(ILI[671:747,1])))
  reallist[i,1+12] <- 1-exp(-(para[45]*sum(ILI[552:670,1])+para[48]*sum(ILI[671:747,1])))
  for (u in 2:6){
    reallist[i,u]<- 1-exp(-(para[43+3*u]*sum(ILI[indrow[[u]],2-u%%2])))
    reallist[i,6+u] <- 1-exp(-(para[44+3*u]*sum(ILI[indrow[[u]],2-u%%2])))
    reallist[i,12+u]<- 1-exp(-(para[45+3*u]*sum(ILI[indrow[[u]],2-u%%2])))
  }
  
  
  temp2$fourfold <- 1*((temp2[,11]-temp2[,10]>=2&temp2[,11]!=-1&temp2[,10]!=-1)|(temp2[,12]-temp2[,11]>=2&temp2[,12]!=-1&temp2[,11]!=-1))

  for (j in 1:6){
    for (k in 0:2){
  fourfoldlist[i,j+6*k] <- mean(temp2$fourfold[temp2[,13]==j-1&temp2[,4]==k])
}
}
  print(i)
}  
for ( i in 1:6){
fourfoldlist[,18+i] <- fourfoldlist[,i]/fourfoldlist[,i+6]  
fourfoldlist[,18+6+i] <- fourfoldlist[,i+12]/fourfoldlist[,i+6]  
reallist[,18+i] <-     reallist[,i]/    reallist[,i+6]  
reallist[,18+6+i] <-     reallist[,i+12]/    reallist[,i+6]  
}

z3 <- para_summary(fourfoldlist,4,3,0)
z4 <- para_summary(reallist,4,3,0)

write.csv(cbind(as.vector(truerisk),z3,z4),"/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/figure4_data_panelA.csv",row.names = F)


