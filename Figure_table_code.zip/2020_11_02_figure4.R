
setwd("/Users/timtsang/SPH Dropbox/Tim Tsang/kiddivax/crossprotection")

data2 <- read.csv("summary/modeladeq.csv")

a3 <- read.csv("summary/figure4_data_panelA.csv")
a4 <- log2(a3[19:30,])

pdf("/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/figure4.pdf",width=8, height=9)
layout(matrix( 1:3, nrow=3,byrow=T))


############################################################################################################################################
## panel A
par(mar=c(5,3.5,2,0))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,3), ylim=c(0,0.6),type="n")



axis(1,at=c(-1,0.5,1.5,2.5,4),labels=c(NA,"Children","Adults","Older adults",NA),cex.axis=1.4,lwd.ticks = 0)
axis(1,at=c(0.5,1.5,2.5),labels=c(NA),cex.axis=1)


axis(2,at=0:6/10,labels=c("0%","10%","20%","30%","40%","50%","60%"), las=1, pos=-0.05)

coltemp <- c("black","red","blue","orange","purple","brown")

points(0.1+0.15*0:5,a3[1:6,1],pch=16,col=coltemp)
points(0.125+0.15*0:5,a3[1:6,2],pch=17,col=coltemp)
points(0.15+0.15*0:5,a3[1:6,6],pch=18,col=coltemp)

points(1+0.1+0.15*0:5,a3[1:6+6,1],pch=16,col=coltemp)
points(1+0.125+0.15*0:5,a3[1:6+6,2],pch=17,col=coltemp)
points(1+0.15+0.15*0:5,a3[1:6+6,6],pch=18,col=coltemp)

points(2+0.1+0.15*0:5,a3[1:6+12,1],pch=16,col=coltemp)
points(2+0.125+0.15*0:5,a3[1:6+12,2],pch=17,col=coltemp)
points(2+0.15+0.15*0:5,a3[1:6+12,6],pch=18,col=coltemp)

for (i in 0:5){
  lines(rep(0.125+0.15*i,2),a3[i+1,3:4],col=coltemp[i+1])  
  lines(rep(1+0.125+0.15*i,2),a3[i+1+6,3:4],col=coltemp[i+1])  
  lines(rep(2+0.125+0.15*i,2),a3[i+1+12,3:4],col=coltemp[i+1])  
  lines(rep(0.15+0.15*i,2),a3[i+1,7:8],col=coltemp[i+1])  
  lines(rep(1+0.15+0.15*i,2),a3[i+1+6,7:8],col=coltemp[i+1])  
  lines(rep(2+0.15+0.15*i,2),a3[i+1+12,7:8],col=coltemp[i+1])  
}



#arrows(1.9,-1.9,1.9,-2,col="brown",length=0.05)
#arrows(1.25+adj1+0.5,-1.9,1.25+adj1+0.5,-2,col="brown",length=0.05)

mtext("Infection probability",side=2,line=2)

legend(1.6,0.6,c("Epidemic 1, H1N1","Epidemic 2, H3N2","Epidemic 3, H1N1","Epidemic 4, H3N2","Epidemic 5, H1N1","Epidemic 6, H3N2")
      ,pch=c(17),lty=1,cex=1,bty="n",col=c("black","red","blue","orange","purple","brown"))

legend(2.3,0.6,c("Simulation value","Estimated by 4-fold rise","Estimated by model")
       ,pch=c(16:18),cex=1,bty="n",col=c("black"))


title(main="A", adj=0)
#abline(h=0,lty=2)
#mtext("Reference group: adults",side=1,line=2.5,cex=1)
mtext("Infection probability by age groups",side=3,line=0.5,cex=0.9)



############################################################################################################################################
## panel B
par(mar=c(5,3,2,0))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,2), ylim=c(-2,2),type="n")



axis(1,at=c(-1,0.5,1.5,3),labels=c(NA,"Children","Older adults",NA),cex.axis=1.4,lwd.ticks = 0)
axis(1,at=c(0.5,1.5),labels=c(NA),cex.axis=1)

a4[,7] <- pmax(a4[,7],-2)
a4[,8] <- pmin(a4[,8],2)


axis(2,at=-2:2,labels=2^c(-2:2), las=1, pos=-0.05)

coltemp <- c("black","red","blue","orange","purple","brown")

points(0.1+0.15*0:5,a4[1:6,1],pch=16,col=coltemp)
points(0.125+0.15*0:5,a4[1:6,2],pch=17,col=coltemp)
points(0.15+0.15*0:5,a4[1:6,6],pch=18,col=coltemp)

points(1+0.1+0.15*0:5,a4[1:6+6,1],pch=16,col=coltemp)
points(1+0.125+0.15*0:5,a4[1:6+6,2],pch=17,col=coltemp)
points(1+0.15+0.15*0:5,a4[1:6+6,6],pch=18,col=coltemp)

for (i in 0:5){
  lines(rep(0.125+0.15*i,2),a4[i+1,3:4],col=coltemp[i+1])  
  lines(rep(1+0.125+0.15*i,2),a4[i+1+6,3:4],col=coltemp[i+1])  
  lines(rep(0.15+0.15*i,2),a4[i+1,7:8],col=coltemp[i+1])  
  lines(rep(1+0.15+0.15*i,2),a4[i+1+6,7:8],col=coltemp[i+1])  
}



arrows(1.9,-1.9,1.9,-2,col="brown",length=0.05)
arrows(0.75,1.9,0.75,2,col="purple",length=0.05)

mtext("Risk ratio",side=2,line=1.75)




title(main="B", adj=0)
abline(h=0,lty=2)
mtext("Reference group: adults",side=1,line=2.5,cex=1)
mtext("Relative risk by age groups",side=3,line=0.5,cex=0.9)


############################################################################################################################################
## panel C
par(mar=c(4,3,2,0))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,10), ylim=c(0,1),type="n")


axis(1,at=c(-0.5,0:9+0.5,11),labels = c(NA,"[.0-.1]","(.1-.2]","(.2-.3]","(.3-.4]","(.4-.5]","(.5-.6]","(.6-.7]","(.7-.8]","(.8-.9]","(.9-1.0]",NA),cex.axis=1)

axis(2,at=0:5/5, las=1, pos=-0.15)

points(0:9+0.5,data2[2:11,2],pch=16)
for (i in 1:10){
lines(rep(i-0.5,2),data2[i+1,3:4])  
  polygon( c(i-0.4,i-0.4,c(i-0.6,i-0.6)),c( i/10,((i-1)/10),rev(c( i/10,((i-1)/10) )) ),col=rgb(1,0,0,0.3),border=NA)
}

lines(c(0.5,9.5),c(0.05,0.95),lty=2)

mtext("Infection probability zone", side=1, line=2.5,cex=1)
mtext("Proportion of infections", side=2, line=1.75,cex=1)

mtext("Model predicted infection probability zone vs observed proportion of infections", side=3, line=0.5,cex=1)

#mtext("H1N1",side=3,line=0.5,at=2)
#mtext("H3N2",side=3,line=0.5,at=2+adjust)
title(main="C", adj=0)




dev.off()



