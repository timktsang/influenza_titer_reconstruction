# heat map

library(plotrix)
library(ggplot2)
library(MASS)
library(scales)
library(grid)
library(Hmisc)
library(psych)

data1 <- read.csv("/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/figure3_data_unadjusted.csv")[,-1]
data2 <- read.csv("/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/figure3_data_adjusted.csv")[1:15*2-1,-1]

data1 <- log2(exp(data1))
data2 <- log2(exp(data2))

GS <- data.frame(rbind(data1[,rep(1,3)],data2[c(1:15,1:6),rep(1,3)]))
GS[,1] <- c( c(1,1:2,1:3,1:4,1:5),c(2,rep(3,2),rep(4,3),rep(5,4),rep(6,5)) ,1:6 ) - 1
GS[,2] <- c( c(2,rep(3,2),rep(4,3),rep(5,4),rep(6,5)),c(1,1:2,1:3,1:4,1:5) ,1:6 ) - 1
GS[31:36,3] <- 0

names(GS) <- c("Var1","Var2","OR")
GS[,1] <- as.factor(GS[,1])
GS[,2] <- as.factor(GS[,2])
# heatmap
base_size <- 6

xvec <- c("1: H1N1","2: H3N2","3: H1N1","4: H3N2","5: H1N1","6: H3N2")


p1 <- ggplot(GS, aes(Var1, Var2)) + 
  geom_tile(aes(fill = OR),colour = "white") +  
  scale_fill_gradient2(low = "darkorchid4", mid = "white", high = "darkorange2",midpoint = 0,limits=c(-4,4), breaks=c((-4:4)),labels=2^(-4:4) )+ 
  theme_grey(base_size = base_size) + 
  geom_abline(intercept = 0, slope = 1, col="gray") +
  labs(title="", x ="Children", y = "",tag = "A") + 
  scale_x_discrete(expand = c(0, 0),labels=xvec) +
  scale_y_discrete(expand = c(0, 0),labels=xvec) + 
  annotate("text", x=1, y=3, label= "0.07", fontface =2,size=6.5) + 
  annotate("text", x=1, y=5, label= "0.24", fontface =2,size=6.5) + 
  annotate("text", x=3.35, y=3.65, label= "Unadjusted", fontface =2,size=5,angle=42) + 
  annotate("text", x=3.65, y=3.35, label= "Adjusted by pre-epidemic HAI titer", fontface =2,size=5,angle=42) + 
  theme(legend.position = c(9,8), axis.ticks = element_blank(), plot.title = element_text(hjust=0.5),
        plot.tag = element_text(size=14, colour = "black",vjust = -1, hjust = -1),
        axis.text.x = element_text(size=10, colour = "black"),
        axis.text.y = element_text(size=10, color="black"), axis.title = element_text(size=14),
        plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"))

#p1


GS <- data.frame(rbind(data1[,rep(5,3)],data2[c(1:15,1:6),rep(5,3)]))
GS[,1] <- c( c(1,1:2,1:3,1:4,1:5),c(2,rep(3,2),rep(4,3),rep(5,4),rep(6,5)) ,1:6 ) - 1
GS[,2] <- c( c(2,rep(3,2),rep(4,3),rep(5,4),rep(6,5)),c(1,1:2,1:3,1:4,1:5) ,1:6 ) - 1
GS[31:36,3] <- 0

names(GS) <- c("Var1","Var2","ORs")
GS[,1] <- as.factor(GS[,1])
GS[,2] <- as.factor(GS[,2])


p2 <- ggplot(GS, aes(Var1, Var2)) + 
  geom_tile(aes(fill = ORs),colour = "white") +  
  scale_fill_gradient2(low = "darkorchid4", mid = "white", high = "darkorange2",midpoint = 0,limits=c(-4,4), breaks=c((-4:4)),labels=2^(-4:4)  )+ 
  theme_grey(base_size = base_size) + 
  geom_abline(intercept = 0, slope = 1, col="gray") +
  labs(title="", x ="Adults", y = "", tag = "B") + 
  scale_x_discrete(expand = c(0, 0),labels=xvec) +
  scale_y_discrete(expand = c(0, 0),labels=xvec) + 
#  annotate("text", x=1, y=3, label= "0.07", fontface =2,size=7) + 
#  annotate("text", x=1, y=5, label= "0.22", fontface =2,size=7) + 
  annotate("text", x=3.4, y=3.7, label= "Unadjusted", fontface =2,size=5,angle=42) + 
  annotate("text", x=3.7, y=3.4, label= "Adjusted by pre-epidemic HAI titer", fontface =2,size=5,angle=42) + 
  theme(legend.text = element_text(color = "black", size = 10), 
        legend.title = element_text(color = "black", size = 10), 
        legend.key.size = unit(1, "cm"),
        plot.tag = element_text(size=14, colour = "black",vjust = -1, hjust  = -1),
    axis.ticks = element_blank(), plot.title = element_text(hjust=0.5),
        axis.text.x = element_text(size=10, colour = "black"),
        axis.text.y = element_text(size=10, color="black"), axis.title = element_text(size=14),
        plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm"))

#p1

######
require(gridExtra)
pdf("/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/figure3.pdf",width=10.5,height=4.5)
#windows(width=8,height=8)

grid.arrange(p1,p2,
             layout_matrix=matrix(c(rep(1,13),rep(2,16)),nrow=1), top=textGrob(expression(bold("Association between infection status in different epidemics")),gp=gpar(fontsize=18)))
dev.off()


