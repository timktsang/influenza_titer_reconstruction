# model adequency

a1 <- read.csv("/Users/timtsang/Dropbox/kiddivax/crossprotection/program_rcpp/realdata_v67/modeladeq_0.499201831175014.csv")
out2 <- a1[,-1]


plotfunction <- function(plotdata,title1,title2){
  ## panel A
  par(mar=c(4,4,4,1))
  
  plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,9), ylim=c(0,0.6),type="n")
  
  axis(1,at=c(-1,1:9-0.5,10),labels=c(NA,expression(""<="-4"),-3:3,expression("">="4"),NA),cex.axis=1)
  axis(2,at=0:6/10, las=1, pos=-0.1)
  
  points(0:8+0.45,plotdata[,4],pch=17,col="black")
  
  points(0:8+0.55,plotdata[,1],pch=16,col="black")

  
  ## here get the line
  for (i in 1:9){
    lines(rep(i-1+0.55,2),plotdata[i,2:3],col="black")  
  }
  
  
  mtext("Proportion",side=2,line=2.5)

   mtext(expression(paste("Change in titers in ","log"[2]," scale")),side=1,line=3)
        
        
  #mtext("pH1",side=1,line=2.5,at=1.5)
  #mtext("sH3",side=1,line=2.5,at=4.5)
  
  #legend(4,600,c("Observed","Estimated"),pch=16:17,cex=0.9,bty="n")
  
  mtext(title1,side=3,line=1.5)
  title(main=title2, adj=0)
}


pdf("/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/figureS3.pdf",width=6, height=15)
layout(matrix( 1:12, nrow=6,byrow=T))
#plotfunction(out2[1:9,1:4],"Epidemic 1 - Overall","A")
plotfunction(out2[1:9+9,1:4],"Epidemic 1 - Children","A")
plotfunction(out2[1:9+18,1:4],"Epidemic 1 - Adults","B")
#plotfunction(out2[1:9,1:4+4],"Epidemic 2 - Overall","D")
plotfunction(out2[1:9+9,1:4+4],"Epidemic 2 - Children","C")
plotfunction(out2[1:9+18,1:4+4],"Epidemic 2 - Adults","D")
#plotfunction(out2[1:9,1:4+8],"Epidemic 3 - Overall","G")
plotfunction(out2[1:9+9,1:4+8],"Epidemic 3 - Children","E")
plotfunction(out2[1:9+18,1:4+8],"Epidemic 3 - Adults","F")
#plotfunction(out2[1:9,1:4+12],"Epidemic 4 - Overall","J")
plotfunction(out2[1:9+9,1:4+12],"Epidemic 4 - Children","G")
plotfunction(out2[1:9+18,1:4+12],"Epidemic 4 - Adults","H")
#plotfunction(out2[1:9,1:4+16],"Epidemic 5 - Overall","M")
plotfunction(out2[1:9+9,1:4+16],"Epidemic 5 - Children","I")
plotfunction(out2[1:9+18,1:4+16],"Epidemic 5 - Adults","J")
#plotfunction(out2[1:9,1:4+20],"Epidemic 6 - Overall","P")
plotfunction(out2[1:9+9,1:4+20],"Epidemic 6 - Children","K")
plotfunction(out2[1:9+18,1:4+20],"Epidemic 6 - Adults","L")
dev.off()



