## testing code for adding pre-season HAI titer

library(chron)

## the program is to use the imputed infection status to do analysis on correlate

setwd("/Users/timtsang/Dropbox/kiddivax/crossprotection/program_rcpp/realdata_v67")
setwd("Z:/kiddivax/crossprotection/program_rcpp/realdata_v67")

load("/Users/timtsang/Dropbox/kiddivax/crossprotection/program_rcpp/realdata_v67/image_0.499201831175014.Rdata")
load("Z:/kiddivax/crossprotection/program_rcpp/realdata_v67/image_0.499201831175014.Rdata")


########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975),na.rm=T)
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}


impute <- tt[[13]]
imputeHAI <- tt[[17]]
imputeboosting <- tt[[16]]

temp <- data.frame(cbind(data1,impute[1450,],imputeboosting[1450,]))
temp$uid <- paste(temp[,1],temp[,2],sep="-")
names(temp)[c(3,9,12,14,16)] <- c("age","HAI","season","inf","boosting")
temp$age[temp$age==2] <- 1


regfunction <- function(varname1,varname2,data){
  a1 <- glm( paste(varname1,"~",varname2),data=data,family=binomial("logit"))
  a2 <- coef(summary(a1))
  if (nrow(a2)>1){
  return(a2[2,1])
  }
  else{
    return(NA)
  }
}

regfunction2 <- function(varname1,varname2,data){
  a1 <- glm( paste(varname1,"~",varname2),data=data,family=binomial("logit"))
  a2 <- coef(summary(a1))
  return(a2[2:3,1])
}

################################################################################
## unadjusted
record1 <- matrix(NA,10000,15)
record2 <- matrix(NA,10000,15)

for (ii in 1:100){
  print(ii)
  # first select the data
  index <- sample(1:10000,1)
  temp$inf <- impute[index,]
  temp$HAI <- imputeHAI[index,]
  temp2 <- reshape(temp[,c("uid","age","season","inf","HAI")],idvar="uid",timevar="season",direction = "wide")
  ## HAI protection
  for (jj in 1:100){
    temp3 <- temp2[sample(1:nrow(temp2),replace=T),]
    ###############################################################################################
    ## s2 on s1
    record1[100*(ii-1)+jj,1] <- regfunction("inf.1","inf.0",temp3[temp3$age.1==0,])
    record2[100*(ii-1)+jj,1] <- regfunction("inf.1","inf.0",temp3[temp3$age.1==1,])
    ###############################################################################################
    ## s3 on s1-2
    record1[100*(ii-1)+jj,2] <- regfunction("inf.2","inf.0",temp3[temp3$age.2==0,])
    record2[100*(ii-1)+jj,2] <- regfunction("inf.2","inf.0",temp3[temp3$age.2==1,])
    record1[100*(ii-1)+jj,3] <- regfunction("inf.2","inf.1",temp3[temp3$age.2==0,])
    record2[100*(ii-1)+jj,3] <- regfunction("inf.2","inf.1",temp3[temp3$age.2==1,])
    ###############################################################################################
    ## s4 on s1-3
    record1[100*(ii-1)+jj,4] <- regfunction("inf.3","inf.0",temp3[temp3$age.3==0,])
    record2[100*(ii-1)+jj,4] <- regfunction("inf.3","inf.0",temp3[temp3$age.3==1,])
    record1[100*(ii-1)+jj,5] <- regfunction("inf.3","inf.1",temp3[temp3$age.3==0,])
    record2[100*(ii-1)+jj,5] <- regfunction("inf.3","inf.1",temp3[temp3$age.3==1,])
    record1[100*(ii-1)+jj,6] <- regfunction("inf.3","inf.2",temp3[temp3$age.3==0,])
    record2[100*(ii-1)+jj,6] <- regfunction("inf.3","inf.2",temp3[temp3$age.3==1,])
    ###############################################################################################
    ## s5 on s1-4
    record1[100*(ii-1)+jj,7] <- regfunction("inf.4","inf.0",temp3[temp3$age.4==0,])
    record2[100*(ii-1)+jj,7] <- regfunction("inf.4","inf.0",temp3[temp3$age.4==1,])
    record1[100*(ii-1)+jj,8] <- regfunction("inf.4","inf.1",temp3[temp3$age.4==0,])
    record2[100*(ii-1)+jj,8] <- regfunction("inf.4","inf.1",temp3[temp3$age.4==1,])
    record1[100*(ii-1)+jj,9] <- regfunction("inf.4","inf.2",temp3[temp3$age.4==0,])
    record2[100*(ii-1)+jj,9] <- regfunction("inf.4","inf.2",temp3[temp3$age.4==1,])
    record1[100*(ii-1)+jj,10] <- regfunction("inf.4","inf.3",temp3[temp3$age.4==0,])
    record2[100*(ii-1)+jj,10] <- regfunction("inf.4","inf.3",temp3[temp3$age.4==1,])
    ###############################################################################################
    ## s6 on s1-5
    record1[100*(ii-1)+jj,11] <- regfunction("inf.5","inf.0",temp3[temp3$age.5==0,])
    record2[100*(ii-1)+jj,11] <- regfunction("inf.5","inf.0",temp3[temp3$age.5==1,])
    record1[100*(ii-1)+jj,12] <- regfunction("inf.5","inf.1",temp3[temp3$age.5==0,])
    record2[100*(ii-1)+jj,12] <- regfunction("inf.5","inf.1",temp3[temp3$age.5==1,])
    record1[100*(ii-1)+jj,13] <- regfunction("inf.5","inf.2",temp3[temp3$age.5==0,])
    record2[100*(ii-1)+jj,13] <- regfunction("inf.5","inf.2",temp3[temp3$age.5==1,])
    record1[100*(ii-1)+jj,14] <- regfunction("inf.5","inf.3",temp3[temp3$age.5==0,])
    record2[100*(ii-1)+jj,14] <- regfunction("inf.5","inf.3",temp3[temp3$age.5==1,])
    record1[100*(ii-1)+jj,15] <- regfunction("inf.5","inf.4",temp3[temp3$age.5==0,])
    record2[100*(ii-1)+jj,15] <- regfunction("inf.5","inf.4",temp3[temp3$age.5==1,])
  }
}


z1 <- para_summary(record1[,1:15],4,3,0)
z2 <- para_summary(record2[,1:15],4,3,0)

write.csv(cbind(z1,z2),"/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/figure3_data_unadjusted.csv")
write.csv(cbind(z1,z2),"Z:/kiddivax/crossprotection/summary/figure3_data_unadjusted.csv")


################################################################################
## adjust for hai titer
record1a <- matrix(NA,10000,30)
record2a <- matrix(NA,10000,30)
for (ii in 1:100){
print(ii)
# first select the data
index <- sample(1:10000,1)
temp$inf <- impute[index,]
temp$HAI <- imputeHAI[index,]
temp2 <- reshape(temp[,c("uid","age","season","inf","HAI")],idvar="uid",timevar="season",direction = "wide")
## HAI protection
for (jj in 1:100){
temp3 <- temp2[sample(1:nrow(temp2),replace=T),]

## adjust for hai titer
###############################################################################################
## s2 on s1
record1a[100*(ii-1)+jj,1:2] <- regfunction2("inf.1","inf.0+HAI.1",temp3[temp3$age.1==0,])
record2a[100*(ii-1)+jj,1:2] <- regfunction2("inf.1","inf.0+HAI.1",temp3[temp3$age.1==1,])
###############################################################################################
## s3 on s1-2
record1a[100*(ii-1)+jj,3:4] <- regfunction2("inf.2","inf.0+HAI.2",temp3[temp3$age.2==0,])
record2a[100*(ii-1)+jj,3:4] <- regfunction2("inf.2","inf.0+HAI.2",temp3[temp3$age.2==1,])
record1a[100*(ii-1)+jj,5:6] <- regfunction2("inf.2","inf.1+HAI.2",temp3[temp3$age.2==0,])
record2a[100*(ii-1)+jj,5:6] <- regfunction2("inf.2","inf.1+HAI.2",temp3[temp3$age.2==1,])
###############################################################################################
## s4 on s1-3
record1a[100*(ii-1)+jj,7:8] <- regfunction2("inf.3","inf.0+HAI.3",temp3[temp3$age.3==0,])
record2a[100*(ii-1)+jj,7:8] <- regfunction2("inf.3","inf.0+HAI.3",temp3[temp3$age.3==1,])
record1a[100*(ii-1)+jj,9:10] <- regfunction2("inf.3","inf.1+HAI.3",temp3[temp3$age.3==0,])
record2a[100*(ii-1)+jj,9:10] <- regfunction2("inf.3","inf.1+HAI.3",temp3[temp3$age.3==1,])
record1a[100*(ii-1)+jj,11:12] <- regfunction2("inf.3","inf.2+HAI.3",temp3[temp3$age.3==0,])
record2a[100*(ii-1)+jj,11:12] <- regfunction2("inf.3","inf.2+HAI.3",temp3[temp3$age.3==1,])
###############################################################################################
## s5 on s1-4
record1a[100*(ii-1)+jj,13:14] <- regfunction2("inf.4","inf.0+HAI.4",temp3[temp3$age.4==0,])
record2a[100*(ii-1)+jj,13:14] <- regfunction2("inf.4","inf.0+HAI.4",temp3[temp3$age.4==1,])
record1a[100*(ii-1)+jj,15:16] <- regfunction2("inf.4","inf.1+HAI.4",temp3[temp3$age.4==0,])
record2a[100*(ii-1)+jj,15:16] <- regfunction2("inf.4","inf.1+HAI.4",temp3[temp3$age.4==1,])
record1a[100*(ii-1)+jj,17:18] <- regfunction2("inf.4","inf.2+HAI.4",temp3[temp3$age.4==0,])
record2a[100*(ii-1)+jj,17:18] <- regfunction2("inf.4","inf.2+HAI.4",temp3[temp3$age.4==1,])
record1a[100*(ii-1)+jj,19:20] <- regfunction2("inf.4","inf.3+HAI.4",temp3[temp3$age.4==0,])
record2a[100*(ii-1)+jj,19:20] <- regfunction2("inf.4","inf.3+HAI.4",temp3[temp3$age.4==1,])
###############################################################################################
## s6 on s1-5
record1a[100*(ii-1)+jj,21:22] <- regfunction2("inf.5","inf.0+HAI.5",temp3[temp3$age.5==0,])
record2a[100*(ii-1)+jj,21:22] <- regfunction2("inf.5","inf.0+HAI.5",temp3[temp3$age.5==1,])
record1a[100*(ii-1)+jj,23:24] <- regfunction2("inf.5","inf.1+HAI.5",temp3[temp3$age.5==0,])
record2a[100*(ii-1)+jj,23:24] <- regfunction2("inf.5","inf.1+HAI.5",temp3[temp3$age.5==1,])
record1a[100*(ii-1)+jj,25:26] <- regfunction2("inf.5","inf.2+HAI.5",temp3[temp3$age.5==0,])
record2a[100*(ii-1)+jj,25:26] <- regfunction2("inf.5","inf.2+HAI.5",temp3[temp3$age.5==1,])
record1a[100*(ii-1)+jj,27:28] <- regfunction2("inf.5","inf.3+HAI.5",temp3[temp3$age.5==0,])
record2a[100*(ii-1)+jj,27:28] <- regfunction2("inf.5","inf.3+HAI.5",temp3[temp3$age.5==1,])
record1a[100*(ii-1)+jj,29:30] <- regfunction2("inf.5","inf.4+HAI.5",temp3[temp3$age.5==0,])
record2a[100*(ii-1)+jj,29:30] <- regfunction2("inf.5","inf.4+HAI.5",temp3[temp3$age.5==1,])

}
}


z1a <- para_summary(record1a,4,3,0)
z2a <- para_summary(record2a,4,3,0)

write.csv(cbind(z1a,z2a),"/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/figure3_data_adjusted.csv")
write.csv(cbind(z1a,z2a),"Z:/kiddivax/crossprotection/summary/figure3_data_adjusted.csv")


################################################################################################################################################################
## explore only
################################################################################
## restrict titer to be <3

record3 <- matrix(NA,10000,15)
record4 <- matrix(NA,10000,15)

for (ii in 1:100){
  print(ii)
  # first select the data
  index <- sample(1:10000,1)
  temp$inf <- impute[index,]
  temp$HAI <- imputeHAI[index,]
  temp2 <- reshape(temp[,c("uid","age","season","inf","HAI")],idvar="uid",timevar="season",direction = "wide")
  ## HAI protection
  for (jj in 1:100){
    temp3 <- temp2[sample(1:nrow(temp2),replace=T),]
    
    ###############################################################################################
    ## s2 on s1
    record3[100*(ii-1)+jj,1] <- regfunction("inf.1","inf.0",temp3[temp3$HAI.1<3&temp3$age.1==0,])
    record4[100*(ii-1)+jj,1] <- regfunction("inf.1","inf.0",temp3[temp3$HAI.1<3&temp3$age.1==1,])
    ###############################################################################################
    ## s3 on s1-2
    record3[100*(ii-1)+jj,2] <- regfunction("inf.2","inf.0",temp3[temp3$HAI.2<3&temp3$age.2==0,])
    record4[100*(ii-1)+jj,2] <- regfunction("inf.2","inf.0",temp3[temp3$HAI.2<3&temp3$age.2==1,])
    record3[100*(ii-1)+jj,3] <- regfunction("inf.2","inf.1",temp3[temp3$HAI.2<3&temp3$age.2==0,])
    record4[100*(ii-1)+jj,3] <- regfunction("inf.2","inf.1",temp3[temp3$HAI.2<3&temp3$age.2==1,])
    ###############################################################################################
    ## s4 on s1-3
    record3[100*(ii-1)+jj,4] <- regfunction("inf.3","inf.0",temp3[temp3$HAI.3<3&temp3$age.3==0,])
    record4[100*(ii-1)+jj,4] <- regfunction("inf.3","inf.0",temp3[temp3$HAI.3<3&temp3$age.3==1,])
    record3[100*(ii-1)+jj,5] <- regfunction("inf.3","inf.1",temp3[temp3$HAI.3<3&temp3$age.3==0,])
    record4[100*(ii-1)+jj,5] <- regfunction("inf.3","inf.1",temp3[temp3$HAI.3<3&temp3$age.3==1,])
    record3[100*(ii-1)+jj,6] <- regfunction("inf.3","inf.2",temp3[temp3$HAI.3<3&temp3$age.3==0,])
    record4[100*(ii-1)+jj,6] <- regfunction("inf.3","inf.2",temp3[temp3$HAI.3<3&temp3$age.3==1,])
    ###############################################################################################
    ## s5 on s1-4
    record3[100*(ii-1)+jj,7] <- regfunction("inf.4","inf.0",temp3[temp3$HAI.4<3&temp3$age.4==0,])
    record4[100*(ii-1)+jj,7] <- regfunction("inf.4","inf.0",temp3[temp3$HAI.4<3&temp3$age.4==1,])
    record3[100*(ii-1)+jj,8] <- regfunction("inf.4","inf.1",temp3[temp3$HAI.4<3&temp3$age.4==0,])
    record4[100*(ii-1)+jj,8] <- regfunction("inf.4","inf.1",temp3[temp3$HAI.4<3&temp3$age.4==1,])
    record3[100*(ii-1)+jj,9] <- regfunction("inf.4","inf.2",temp3[temp3$HAI.4<3&temp3$age.4==0,])
    record4[100*(ii-1)+jj,9] <- regfunction("inf.4","inf.2",temp3[temp3$HAI.4<3&temp3$age.4==1,])
    record3[100*(ii-1)+jj,10] <- regfunction("inf.4","inf.3",temp3[temp3$HAI.4<3&temp3$age.4==0,])
    record4[100*(ii-1)+jj,10] <- regfunction("inf.4","inf.3",temp3[temp3$HAI.4<3&temp3$age.4==1,])
    ###############################################################################################
    ## s6 on s1-5
    record3[100*(ii-1)+jj,11] <- regfunction("inf.5","inf.0",temp3[temp3$HAI.5<3&temp3$age.5==0,])
    record4[100*(ii-1)+jj,11] <- regfunction("inf.5","inf.0",temp3[temp3$HAI.5<3&temp3$age.5==1,])
    record3[100*(ii-1)+jj,12] <- regfunction("inf.5","inf.1",temp3[temp3$HAI.5<3&temp3$age.5==0,])
    record4[100*(ii-1)+jj,12] <- regfunction("inf.5","inf.1",temp3[temp3$HAI.5<3&temp3$age.5==1,])
    record3[100*(ii-1)+jj,13] <- regfunction("inf.5","inf.2",temp3[temp3$HAI.5<3&temp3$age.5==0,])
    record4[100*(ii-1)+jj,13] <- regfunction("inf.5","inf.2",temp3[temp3$HAI.5<3&temp3$age.5==1,])
    record3[100*(ii-1)+jj,14] <- regfunction("inf.5","inf.3",temp3[temp3$HAI.5<3&temp3$age.5==0,])
    record4[100*(ii-1)+jj,14] <- regfunction("inf.5","inf.3",temp3[temp3$HAI.5<3&temp3$age.5==1,])
    record3[100*(ii-1)+jj,15] <- regfunction("inf.5","inf.4",temp3[temp3$HAI.5<3&temp3$age.5==0,])
    record4[100*(ii-1)+jj,15] <- regfunction("inf.5","inf.4",temp3[temp3$HAI.5<3&temp3$age.5==1,])
    
  }
}




z3 <- para_summary(record3[,1:15],4,3,0)
z4 <- para_summary(record4[,1:15],4,3,0)


#write.csv(cbind(z3,z4),"/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/figureS2_data_part3.csv")




################################################################################
## restrict titer to be <1

record3a <- matrix(NA,10000,15)
record4a <- matrix(NA,10000,15)

for (ii in 1:100){
  print(ii)
  # first select the data
  index <- sample(1:10000,1)
  temp$inf <- impute[index,]
  temp$HAI <- imputeHAI[index,]
  temp2 <- reshape(temp[,c("uid","age","season","inf","HAI")],idvar="uid",timevar="season",direction = "wide")
  ## HAI protection
  for (jj in 1:100){
    temp3 <- temp2[sample(1:nrow(temp2),replace=T),]
    
   
    ###############################################################################################
    ## s2 on s1
    record3a[100*(ii-1)+jj,1] <- regfunction("inf.1","inf.0",temp3[temp3$HAI.1<1&temp3$age.1==0,])
    record4a[100*(ii-1)+jj,1] <- regfunction("inf.1","inf.0",temp3[temp3$HAI.1<1&temp3$age.1==1,])
    ###############################################################################################
    ## s3 on s1-2
    record3a[100*(ii-1)+jj,2] <- regfunction("inf.2","inf.0",temp3[temp3$HAI.2<1&temp3$age.2==0,])
    record4a[100*(ii-1)+jj,2] <- regfunction("inf.2","inf.0",temp3[temp3$HAI.2<1&temp3$age.2==1,])
    record3a[100*(ii-1)+jj,3] <- regfunction("inf.2","inf.1",temp3[temp3$HAI.2<1&temp3$age.2==0,])
    record4a[100*(ii-1)+jj,3] <- regfunction("inf.2","inf.1",temp3[temp3$HAI.2<1&temp3$age.2==1,])
    ###############################################################################################
    ## s4 on s1-3
    record3a[100*(ii-1)+jj,4] <- regfunction("inf.3","inf.0",temp3[temp3$HAI.3<1&temp3$age.3==0,])
    record4a[100*(ii-1)+jj,4] <- regfunction("inf.3","inf.0",temp3[temp3$HAI.3<1&temp3$age.3==1,])
    record3a[100*(ii-1)+jj,5] <- regfunction("inf.3","inf.1",temp3[temp3$HAI.3<1&temp3$age.3==0,])
    record4a[100*(ii-1)+jj,5] <- regfunction("inf.3","inf.1",temp3[temp3$HAI.3<1&temp3$age.3==1,])
    record3a[100*(ii-1)+jj,6] <- regfunction("inf.3","inf.2",temp3[temp3$HAI.3<1&temp3$age.3==0,])
    record4a[100*(ii-1)+jj,6] <- regfunction("inf.3","inf.2",temp3[temp3$HAI.3<1&temp3$age.3==1,])
    ###############################################################################################
    ## s5 on s1-4
    record3a[100*(ii-1)+jj,7] <- regfunction("inf.4","inf.0",temp3[temp3$HAI.4<1&temp3$age.4==0,])
    record4a[100*(ii-1)+jj,7] <- regfunction("inf.4","inf.0",temp3[temp3$HAI.4<1&temp3$age.4==1,])
    record3a[100*(ii-1)+jj,8] <- regfunction("inf.4","inf.1",temp3[temp3$HAI.4<1&temp3$age.4==0,])
    record4a[100*(ii-1)+jj,8] <- regfunction("inf.4","inf.1",temp3[temp3$HAI.4<1&temp3$age.4==1,])
    record3a[100*(ii-1)+jj,9] <- regfunction("inf.4","inf.2",temp3[temp3$HAI.4<1&temp3$age.4==0,])
    record4a[100*(ii-1)+jj,9] <- regfunction("inf.4","inf.2",temp3[temp3$HAI.4<1&temp3$age.4==1,])
    record3a[100*(ii-1)+jj,10] <- regfunction("inf.4","inf.3",temp3[temp3$HAI.4<1&temp3$age.4==0,])
    record4a[100*(ii-1)+jj,10] <- regfunction("inf.4","inf.3",temp3[temp3$HAI.4<1&temp3$age.4==1,])
    ###############################################################################################
    ## s6 on s1-5
    record3a[100*(ii-1)+jj,11] <- regfunction("inf.5","inf.0",temp3[temp3$HAI.5<1&temp3$age.5==0,])
    record4a[100*(ii-1)+jj,11] <- regfunction("inf.5","inf.0",temp3[temp3$HAI.5<1&temp3$age.5==1,])
    record3a[100*(ii-1)+jj,12] <- regfunction("inf.5","inf.1",temp3[temp3$HAI.5<1&temp3$age.5==0,])
    record4a[100*(ii-1)+jj,12] <- regfunction("inf.5","inf.1",temp3[temp3$HAI.5<1&temp3$age.5==1,])
    record3a[100*(ii-1)+jj,13] <- regfunction("inf.5","inf.2",temp3[temp3$HAI.5<1&temp3$age.5==0,])
    record4a[100*(ii-1)+jj,13] <- regfunction("inf.5","inf.2",temp3[temp3$HAI.5<1&temp3$age.5==1,])
    record3a[100*(ii-1)+jj,14] <- regfunction("inf.5","inf.3",temp3[temp3$HAI.5<1&temp3$age.5==0,])
    record4a[100*(ii-1)+jj,14] <- regfunction("inf.5","inf.3",temp3[temp3$HAI.5<1&temp3$age.5==1,])
    record3a[100*(ii-1)+jj,15] <- regfunction("inf.5","inf.4",temp3[temp3$HAI.5<1&temp3$age.5==0,])
    record4a[100*(ii-1)+jj,15] <- regfunction("inf.5","inf.4",temp3[temp3$HAI.5<1&temp3$age.5==1,])
    
  }
}



z3a <- para_summary(record3a,4,3,0)
z4a <- para_summary(record4a,4,3,0)

#write.csv(cbind(z3a,z4a),"/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/figureS2_data_part4.csv")




################################################################################
## restrict titer to be <2

record3a <- matrix(NA,10000,15)
record4a <- matrix(NA,10000,15)

for (ii in 1:100){
  print(ii)
  # first select the data
  index <- sample(1:10000,1)
  temp$inf <- impute[index,]
  temp$HAI <- imputeHAI[index,]
  temp2 <- reshape(temp[,c("uid","age","season","inf","HAI")],idvar="uid",timevar="season",direction = "wide")
  ## HAI protection
  for (jj in 1:100){
    temp3 <- temp2[sample(1:nrow(temp2),replace=T),]
    
    
    ###############################################################################################
    ## s2 on s1
    record3a[100*(ii-1)+jj,1] <- regfunction("inf.1","inf.0",temp3[temp3$HAI.1<2&temp3$age.1==0,])
    record4a[100*(ii-1)+jj,1] <- regfunction("inf.1","inf.0",temp3[temp3$HAI.1<2&temp3$age.1==1,])
    ###############################################################################################
    ## s3 on s1-2
    record3a[100*(ii-1)+jj,2] <- regfunction("inf.2","inf.0",temp3[temp3$HAI.2<2&temp3$age.2==0,])
    record4a[100*(ii-1)+jj,2] <- regfunction("inf.2","inf.0",temp3[temp3$HAI.2<2&temp3$age.2==1,])
    record3a[100*(ii-1)+jj,3] <- regfunction("inf.2","inf.1",temp3[temp3$HAI.2<2&temp3$age.2==0,])
    record4a[100*(ii-1)+jj,3] <- regfunction("inf.2","inf.1",temp3[temp3$HAI.2<2&temp3$age.2==1,])
    ###############################################################################################
    ## s4 on s1-3
    record3a[100*(ii-1)+jj,4] <- regfunction("inf.3","inf.0",temp3[temp3$HAI.3<2&temp3$age.3==0,])
    record4a[100*(ii-1)+jj,4] <- regfunction("inf.3","inf.0",temp3[temp3$HAI.3<2&temp3$age.3==1,])
    record3a[100*(ii-1)+jj,5] <- regfunction("inf.3","inf.1",temp3[temp3$HAI.3<2&temp3$age.3==0,])
    record4a[100*(ii-1)+jj,5] <- regfunction("inf.3","inf.1",temp3[temp3$HAI.3<2&temp3$age.3==1,])
    record3a[100*(ii-1)+jj,6] <- regfunction("inf.3","inf.2",temp3[temp3$HAI.3<2&temp3$age.3==0,])
    record4a[100*(ii-1)+jj,6] <- regfunction("inf.3","inf.2",temp3[temp3$HAI.3<2&temp3$age.3==1,])
    ###############################################################################################
    ## s5 on s1-4
    record3a[100*(ii-1)+jj,7] <- regfunction("inf.4","inf.0",temp3[temp3$HAI.4<2&temp3$age.4==0,])
    record4a[100*(ii-1)+jj,7] <- regfunction("inf.4","inf.0",temp3[temp3$HAI.4<2&temp3$age.4==1,])
    record3a[100*(ii-1)+jj,8] <- regfunction("inf.4","inf.1",temp3[temp3$HAI.4<2&temp3$age.4==0,])
    record4a[100*(ii-1)+jj,8] <- regfunction("inf.4","inf.1",temp3[temp3$HAI.4<2&temp3$age.4==1,])
    record3a[100*(ii-1)+jj,9] <- regfunction("inf.4","inf.2",temp3[temp3$HAI.4<2&temp3$age.4==0,])
    record4a[100*(ii-1)+jj,9] <- regfunction("inf.4","inf.2",temp3[temp3$HAI.4<2&temp3$age.4==1,])
    record3a[100*(ii-1)+jj,10] <- regfunction("inf.4","inf.3",temp3[temp3$HAI.4<2&temp3$age.4==0,])
    record4a[100*(ii-1)+jj,10] <- regfunction("inf.4","inf.3",temp3[temp3$HAI.4<2&temp3$age.4==1,])
    ###############################################################################################
    ## s6 on s1-5
    record3a[100*(ii-1)+jj,11] <- regfunction("inf.5","inf.0",temp3[temp3$HAI.5<2&temp3$age.5==0,])
    record4a[100*(ii-1)+jj,11] <- regfunction("inf.5","inf.0",temp3[temp3$HAI.5<2&temp3$age.5==1,])
    record3a[100*(ii-1)+jj,12] <- regfunction("inf.5","inf.1",temp3[temp3$HAI.5<2&temp3$age.5==0,])
    record4a[100*(ii-1)+jj,12] <- regfunction("inf.5","inf.1",temp3[temp3$HAI.5<2&temp3$age.5==1,])
    record3a[100*(ii-1)+jj,13] <- regfunction("inf.5","inf.2",temp3[temp3$HAI.5<2&temp3$age.5==0,])
    record4a[100*(ii-1)+jj,13] <- regfunction("inf.5","inf.2",temp3[temp3$HAI.5<2&temp3$age.5==1,])
    record3a[100*(ii-1)+jj,14] <- regfunction("inf.5","inf.3",temp3[temp3$HAI.5<2&temp3$age.5==0,])
    record4a[100*(ii-1)+jj,14] <- regfunction("inf.5","inf.3",temp3[temp3$HAI.5<2&temp3$age.5==1,])
    record3a[100*(ii-1)+jj,15] <- regfunction("inf.5","inf.4",temp3[temp3$HAI.5<2&temp3$age.5==0,])
    record4a[100*(ii-1)+jj,15] <- regfunction("inf.5","inf.4",temp3[temp3$HAI.5<2&temp3$age.5==1,])
    
  }
}



z3a <- para_summary(record3a,4,3,0)
z4a <- para_summary(record4a,4,3,0)

#write.csv(cbind(z3a,z4a),"/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/figureS2_data_part5.csv")



