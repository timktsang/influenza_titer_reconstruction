## the program is to use the imputed infection status to do analysis on correlate


data <- read.csv("/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/figure3_data_unadjusted.csv")[,-c(1,5)]

plotdata <- 1-(exp(data))
plotdata <- rbind(plotdata,NA)

vecmat <- matrix(16,5,5)
vecmat[1,] <- c(1,2,4,7,11)
vecmat[2,2:5] <- c(3,5,8,12)
vecmat[3,3:5] <- c(6,9,13)
vecmat[4,4:5] <- c(10,14)
vecmat[5,5] <- 15

pdf("/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/figureS2.pdf",width=9, height=8)
layout(matrix( 1:4, nrow=2,byrow=T))


## panel A
par(mar=c(4,5,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,2), ylim=c(-1,1),type="n")

axis(1,at=c(-1,0.5,1.5,3),labels=c(NA,"3: H1N1","5: H1N1",NA),cex.axis=1)
axis(2,at=-2:2*0.5, las=1,labels=c("-100%","-50%","0%","50%","100%"), pos=-0.2)

points(0:1+0.3,plotdata[vecmat[1,c(2,4)],1],pch=16,col="black")
points(0:1+0.4,plotdata[vecmat[1,c(2,4)],1+3],pch=16,col="black")

points(0:1+0.6,plotdata[vecmat[3,c(2,4)],1],pch=17,col="blue")
points(0:1+0.7,plotdata[vecmat[3,c(2,4)],1+3],pch=17,col="blue")

mtext("Protection",side=2,line=4)


lines(rep(i+0.3,2),pmax(-1,plotdata[vecmat[1,2*i+2],2:3]),col="black",lty=1)  


for (i in 0:1){
  lines(rep(i+0.3,2),pmax(-1,plotdata[vecmat[1,2*i+2],2:3]),col="black",lty=1) 
  lines(rep(i+0.4,2),pmax(-1,plotdata[vecmat[1,2*i+2],2:3+3]),col="black",lty=2) 
  lines(rep(i+0.6,2),pmax(-1,plotdata[vecmat[3,2*i+2],2:3]),col="blue",lty=1) 
  lines(rep(i+0.7,2),pmax(-1,plotdata[vecmat[3,2*i+2],2:3+3]),col="blue",lty=2) 
}

arrows(1.4,-0.99,1.4,-1,col="black",length=0.05)

legend(0,-0.45,c("Infected in 1: H1N1","Infected in 3: H1N1"),pch=16:17,cex=1,bty="n",col=c("black","blue"))
#text(5.43,1,"Previous")
#text(5.5,0.80,"infection in")

legend(0,-0.75,c("Children","Adults"),cex=1,bty="n",lty=c(1,2))

#legend(5,0.8,c("1: H1N1","2: H3N2","3: H1N1","4: H3N2","5: H1N1"),pch=16:20,cex=1,bty="n",col=c("black","blue","purple","red","orange"))

lines(c(0,5),c(0,0),lty=2)
#abline(h=0,lty=2)
#mtext("A",side=3,line=0,at=-0.3)
title(main="A", adj=0)
mtext("H1N1 homosubtypic protection", side=3, line=0.5,cex=1)
mtext("Protection in epidemic", side=1, line=2.25,cex=1)



## panel B
par(mar=c(4,5,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,2), ylim=c(-1,1),type="n")

axis(1,at=c(-1,0.5,1.5,3),labels=c(NA,"4: H3N2","6: H3N2",NA),cex.axis=1)
axis(2,at=-2:2*0.5, las=1,labels=c("-100%","-50%","0%","50%","100%"), pos=-0.2)

points(0:1+0.3,plotdata[vecmat[2,c(3,5)],1],pch=16,col="black")
points(0:1+0.4,plotdata[vecmat[2,c(3,5)],1+3],pch=16,col="black")

points(0:1+0.6,plotdata[vecmat[4,c(3,5)],1],pch=17,col="blue")
points(0:1+0.7,plotdata[vecmat[4,c(3,5)],1+3],pch=17,col="blue")

mtext("Protection",side=2,line=4)


for (i in 0:1){
  lines(rep(i+0.3,2),pmax(-1,plotdata[vecmat[2,3*i+2],2:3]),col="black",lty=1) 
  lines(rep(i+0.4,2),pmax(-1,plotdata[vecmat[2,3*i+2],2:3+3]),col="black",lty=2) 
  lines(rep(i+0.6,2),pmax(-1,plotdata[vecmat[4,3*i+2],2:3]),col="blue",lty=1) 
  lines(rep(i+0.7,2),pmax(-1,plotdata[vecmat[4,3*i+2],2:3+3]),col="blue",lty=2) 
}

arrows(1.4,-0.99,1.4,-1,col="black",length=0.05)
arrows(1.3,-0.99,1.3,-1,col="black",length=0.05)
arrows(0.3,-0.99,0.3,-1,col="black",length=0.05)

legend(0,1.1,c("Infected in 2: H3N2","Infected in 4: H3N2"),pch=16:17,cex=1,bty="n",col=c("black","blue"))
#text(5.43,1,"Previous")
#text(5.5,0.80,"infection in")

#legend(0,-0.75,c("Children","Adults"),cex=1,bty="n",lty=c(1,2))

#legend(5,0.8,c("1: H1N1","2: H3N2","3: H1N1","4: H3N2","5: H1N1"),pch=16:20,cex=1,bty="n",col=c("black","blue","purple","red","orange"))

lines(c(0,5),c(0,0),lty=2)
#abline(h=0,lty=2)
#mtext("A",side=3,line=0,at=-0.3)
title(main="B", adj=0)
mtext("H3N2 homosubtypic protection", side=3, line=0.5,cex=1)
mtext("Protection in epidemic", side=1, line=2.25,cex=1)





## panel C
par(mar=c(4,5,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,2), ylim=c(-1,1),type="n")

axis(1,at=c(-1,0.5,1.5,3),labels=c(NA,"3: H1N1","5: H1N1",NA),cex.axis=1)
axis(2,at=-2:2*0.5, las=1,labels=c("-100%","-50%","0%","50%","100%"), pos=-0.2)

points(0:1+0.3,plotdata[vecmat[2,c(2,4)],1],pch=16,col="black")
points(0:1+0.4,plotdata[vecmat[2,c(2,4)],1+3],pch=16,col="black")

points(0:1+0.6,plotdata[vecmat[4,c(2,4)],1],pch=17,col="blue")
points(0:1+0.7,plotdata[vecmat[4,c(2,4)],1+3],pch=17,col="blue")

mtext("Protection",side=2,line=4)


for (i in 0:1){
  lines(rep(i+0.3,2),pmax(-1,plotdata[vecmat[2,2*i+2],2:3]),col="black",lty=1) 
  lines(rep(i+0.4,2),pmax(-1,plotdata[vecmat[2,2*i+2],2:3+3]),col="black",lty=2) 
  lines(rep(i+0.6,2),pmax(-1,plotdata[vecmat[4,2*i+2],2:3]),col="blue",lty=1) 
  lines(rep(i+0.7,2),pmax(-1,plotdata[vecmat[4,2*i+2],2:3+3]),col="blue",lty=2) 
}

arrows(1.4,-0.99,1.4,-1,col="black",length=0.05)
arrows(1.3,-0.99,1.3,-1,col="black",length=0.05)
arrows(0.3,-0.99,0.3,-1,col="black",length=0.05)

legend(0,1.1,c("Infected in 2: H3N2","Infected in 4: H3N2"),pch=16:17,cex=1,bty="n",col=c("black","blue"))
#text(5.43,1,"Previous")
#text(5.5,0.80,"infection in")

#legend(0,-0.75,c("Children","Adults"),cex=1,bty="n",lty=c(1,2))

#legend(5,0.8,c("1: H1N1","2: H3N2","3: H1N1","4: H3N2","5: H1N1"),pch=16:20,cex=1,bty="n",col=c("black","blue","purple","red","orange"))

lines(c(0,5),c(0,0),lty=2)
#abline(h=0,lty=2)
#mtext("A",side=3,line=0,at=-0.3)
title(main="C", adj=0)
mtext("H1N1 heterosubtypic protection", side=3, line=0.5,cex=1)
mtext("Protection in epidemic", side=1, line=2.25,cex=1)




## panel D
par(mar=c(4,5,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,3), ylim=c(-1,1),type="n")

axis(1,at=c(-1,0.5,1.5,2.5,4),labels=c(NA,"2: H3N2","4: H3N2","6: H3N2",NA),cex.axis=1)
axis(2,at=-2:2*0.5, las=1,labels=c("-100%","-50%","0%","50%","100%"), pos=-0.2)

points(0:2+0.2,plotdata[vecmat[1,c(1,3,5)],1],pch=16,col="black")
points(0:2+0.3,plotdata[vecmat[1,c(1,3,5)],1+3],pch=16,col="black")

points(0:2+0.45,plotdata[vecmat[3,c(1,3,5)],1],pch=17,col="blue")
points(0:2+0.55,plotdata[vecmat[3,c(1,3,5)],1+3],pch=17,col="blue")

points(0:2+0.7,plotdata[vecmat[5,c(1,3,5)],1],pch=18,col="red")
points(0:2+0.8,plotdata[vecmat[5,c(1,3,5)],1+3],pch=18,col="red")


mtext("Protection",side=2,line=4)


for (i in 0:2){
  lines(rep(i+0.2,2),pmax(-1,plotdata[vecmat[1,2*i+1],2:3]),col="black",lty=1) 
  lines(rep(i+0.3,2),pmax(-1,plotdata[vecmat[1,2*i+1],2:3+3]),col="black",lty=2) 
  lines(rep(i+0.45,2),pmax(-1,plotdata[vecmat[3,2*i+1],2:3]),col="blue",lty=1) 
  lines(rep(i+0.55,2),pmax(-1,plotdata[vecmat[3,2*i+1],2:3+3]),col="blue",lty=2) 
  lines(rep(i+0.7,2),pmax(-1,plotdata[vecmat[5,2*i+1],2:3]),col="red",lty=1) 
  lines(rep(i+0.8,2),pmax(-1,plotdata[vecmat[5,2*i+1],2:3+3]),col="red",lty=2) 
}

arrows(1.2,-0.99,1.2,-1,col="black",length=0.05)
arrows(2.2,-0.99,2.2,-1,col="black",length=0.05)
arrows(2.3,-0.99,2.3,-1,col="black",length=0.05)

arrows(2.45,-0.99,2.45,-1,col="blue",length=0.05)
arrows(2.55,-0.99,2.55,-1,col="blue",length=0.05)

arrows(2.7,-0.99,2.7,-1,col="red",length=0.05)
arrows(2.8,-0.99,2.8,-1,col="red",length=0.05)

legend(0,1.1,c("Infected in 1: H1N1","Infected in 3: H1N1","Infected in 5: H1N1"),pch=16:18,cex=1,bty="n",col=c("black","blue","red"))
#text(5.43,1,"Previous")
#text(5.5,0.80,"infection in")

#legend(0,-0.75,c("Children","Adults"),cex=1,bty="n",lty=c(1,2))

#legend(5,0.8,c("1: H1N1","2: H3N2","3: H1N1","4: H3N2","5: H1N1"),pch=16:20,cex=1,bty="n",col=c("black","blue","purple","red","orange"))

lines(c(0,5),c(0,0),lty=2)
#abline(h=0,lty=2)
#mtext("A",side=3,line=0,at=-0.3)
title(main="C", adj=0)
mtext("H3N2 heterosubtypic protection", side=3, line=0.5,cex=1)
mtext("Protection in epidemic", side=1, line=2.25,cex=1)


dev.off()



