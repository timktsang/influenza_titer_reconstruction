library(chron)

#mcmc <- read.csv("/Users/timtsang/SPH Dropbox/Tim Tsang/kiddivax/crossprotection/program_rcpp/realdata_v67/mcmc_summary_0.499201831175014.csv")

load("/Users/timtsang/SPH Dropbox/Tim Tsang/kiddivax/crossprotection/program_rcpp/realdata_v67/image_0.499201831175014.Rdata")

ILI <- read.csv("/Users/timtsang/SPH Dropbox/Tim Tsang/kiddivax/crossprotection/program_rcpp/realdata_v67/ILILAB_2019_04_25.csv")
inc <- 100000+1:10000*10

mcmc1 <- tt[[1]][inc,]
mcmc2 <- tt[[2]][inc,]

1-exp(colMeans(mcmc1[,c(66,68,70)]))

1-exp(quantile(mcmc1[,66],c(0.025,0.975)))
1-exp(quantile(mcmc1[,68],c(0.025,0.975)))
1-exp(quantile(mcmc1[,70],c(0.025,0.975)))

## first generate table infection risk for 4 seasons

xvec <- 0:100

d1list <- list(NA)
d2list <- list(NA)
d3list <- list(NA)

d1 <- matrix(NA,10000,101)
d2 <- matrix(NA,10000,101)
d3 <- matrix(NA,10000,101)
for (i in 1:10000){
  d1[i,] <- 1-exp(-(mcmc1[i,43]*sum(ILI[552:670,1])+mcmc1[i,46]*sum(ILI[671:747,1]))*exp(xvec/10*mcmc1[i,64]))
  d2[i,] <- 1-exp(-(mcmc1[i,44]*sum(ILI[552:670,1])+mcmc1[i,47]*sum(ILI[671:747,1]))*exp(xvec/10*mcmc1[i,64]))
  d3[i,] <- 1-exp(-(mcmc1[i,45]*sum(ILI[552:670,1])+mcmc1[i,48]*sum(ILI[671:747,1]))*exp(xvec/10*mcmc1[i,64]))
}
d1list[[1]] <- d1
d2list[[1]] <- d2
d3list[[1]] <- d3

indrow <- list(552:747,944:1020,1105:1153,1532:1636,1875:1937,2022:2112)

for (u in 2:6){
  for (i in 1:10000){
    d1[i,] <- 1-exp(-(mcmc1[i,43+3*u]*sum(ILI[indrow[[u]],2-u%%2]))*exp(xvec/10*mcmc1[i,62+2*u]))
    d2[i,] <- 1-exp(-(mcmc1[i,44+3*u]*sum(ILI[indrow[[u]],2-u%%2]))*exp(xvec/10*mcmc1[i,62+2*u]))
    d3[i,] <- 1-exp(-(mcmc1[i,45+3*u]*sum(ILI[indrow[[u]],2-u%%2]))*exp(xvec/10*mcmc1[i,62+2*u]))
  }
  d1list[[u]] <- d1
  d2list[[u]] <- d2
  d3list[[u]] <- d3
}

# 1-3 the naive one, 4-6 the overall one
# risk
plotmatrix11 <- matrix(NA,6,9)
plotmatrix12 <- matrix(NA,6,9)
plotmatrix13 <- matrix(NA,6,9)
plotmatrix14 <- matrix(NA,6,9)
# ratio
plotmatrix21 <- matrix(NA,6,9)
plotmatrix22 <- matrix(NA,6,9)
plotmatrix23 <- matrix(NA,6,9)
plotmatrix24 <- matrix(NA,6,9)


for (uu in 1:6){
  plotmatrix11[uu,1] <- mean(d1list[[uu]][,1])
  plotmatrix11[uu,2:3] <- quantile(d1list[[uu]][,1],c(0.025,0.975))
  plotmatrix11[uu,4] <- mean(d2list[[uu]][,1])
  plotmatrix11[uu,5:6] <- quantile(d2list[[uu]][,1],c(0.025,0.975))
  plotmatrix11[uu,7] <- mean(d3list[[uu]][,1])
  plotmatrix11[uu,8:9] <- quantile(d3list[[uu]][,1],c(0.025,0.975))
  
  plotmatrix13[uu,1] <- mean(d1list[[uu]][,21])
  plotmatrix13[uu,2:3] <- quantile(d1list[[uu]][,21],c(0.025,0.975))
  plotmatrix13[uu,4] <- mean(d2list[[uu]][,21])
  plotmatrix13[uu,5:6] <- quantile(d2list[[uu]][,21],c(0.025,0.975))
  plotmatrix13[uu,7] <- mean(d3list[[uu]][,21])
  plotmatrix13[uu,8:9] <- quantile(d3list[[uu]][,21],c(0.025,0.975))
  
  plotmatrix14[uu,1] <- mean(d1list[[uu]][,41])
  plotmatrix14[uu,2:3] <- quantile(d1list[[uu]][,41],c(0.025,0.975))
  plotmatrix14[uu,4] <- mean(d2list[[uu]][,41])
  plotmatrix14[uu,5:6] <- quantile(d2list[[uu]][,41],c(0.025,0.975))
  plotmatrix14[uu,7] <- mean(d3list[[uu]][,41])
  plotmatrix14[uu,8:9] <- quantile(d3list[[uu]][,41],c(0.025,0.975))
  
  plotmatrix21[uu,1] <- mean(d1list[[uu]][,1]/d2list[[uu]][,1])
  plotmatrix21[uu,2:3] <- quantile(d1list[[uu]][,1]/d2list[[uu]][,1],c(0.025,0.975))
  plotmatrix21[uu,4] <- mean(d2list[[uu]][,1]/d2list[[uu]][,1])
  plotmatrix21[uu,5:6] <- quantile(d2list[[uu]][,1]/d2list[[uu]][,1],c(0.025,0.975))
  plotmatrix21[uu,7] <- mean(d3list[[uu]][,1]/d2list[[uu]][,1])
  plotmatrix21[uu,8:9] <- quantile(d3list[[uu]][,1]/d2list[[uu]][,1],c(0.025,0.975))
  
  plotmatrix23[uu,1] <- mean(d1list[[uu]][,21]/d2list[[uu]][,21])
  plotmatrix23[uu,2:3] <- quantile(d1list[[uu]][,21]/d2list[[uu]][,21],c(0.025,0.975))
  plotmatrix23[uu,4] <- mean(d2list[[uu]][,21]/d2list[[uu]][,21])
  plotmatrix23[uu,5:6] <- quantile(d2list[[uu]][,21]/d2list[[uu]][,21],c(0.025,0.975))
  plotmatrix23[uu,7] <- mean(d3list[[uu]][,21]/d2list[[uu]][,21])
  plotmatrix23[uu,8:9] <- quantile(d3list[[uu]][,21]/d2list[[uu]][,21],c(0.025,0.975))
  
  plotmatrix24[uu,1] <- mean(d1list[[uu]][,41]/d2list[[uu]][,41])
  plotmatrix24[uu,2:3] <- quantile(d1list[[uu]][,41]/d2list[[uu]][,41],c(0.025,0.975))
  plotmatrix24[uu,4] <- mean(d2list[[uu]][,41]/d2list[[uu]][,41])
  plotmatrix24[uu,5:6] <- quantile(d2list[[uu]][,41]/d2list[[uu]][,41],c(0.025,0.975))
  plotmatrix24[uu,7] <- mean(d3list[[uu]][,41]/d2list[[uu]][,41])
  plotmatrix24[uu,8:9] <- quantile(d3list[[uu]][,41]/d2list[[uu]][,41],c(0.025,0.975))
}

for (uu in 1:6){
  vec1 <- rowSums(d1list[[uu]][,c(6+0:9*10)]*mcmc2[,1:10+20*(u-1)])
  vec2 <- rowSums(d2list[[uu]][,c(6+0:9*10)]*mcmc2[,10+1:10+20*(u-1)])
  vec3 <- rowSums(d3list[[uu]][,c(6+0:9*10)]*mcmc2[,10+1:10+20*(u-1)])
  
  plotmatrix12[uu,1] <- mean(vec1 )
  plotmatrix12[uu,2:3] <- quantile(vec1,c(0.025,0.975))
  plotmatrix12[uu,4] <- mean(vec2)
  plotmatrix12[uu,5:6] <- quantile(vec2,c(0.025,0.975))
  plotmatrix12[uu,7] <- mean(vec3)
  plotmatrix12[uu,8:9] <- quantile(vec3,c(0.025,0.975))
  
  plotmatrix22[uu,1] <- mean(vec1/vec2)
  plotmatrix22[uu,2:3] <- quantile(vec1/vec2,c(0.025,0.975))
  plotmatrix22[uu,4] <- mean(vec2/vec2)
  plotmatrix22[uu,5:6] <- quantile(vec2/vec2,c(0.025,0.975))
  plotmatrix22[uu,7] <- mean(vec3/vec2)
  plotmatrix22[uu,8:9] <- quantile(vec3/vec2,c(0.025,0.975))
  
}

plotmatrix21 <- log2(plotmatrix21)
plotmatrix22 <- log2(plotmatrix22)
plotmatrix23 <- log2(plotmatrix23)
plotmatrix24 <- log2(plotmatrix24)


plotmatrix1 <- rbind(plotmatrix12,plotmatrix11,plotmatrix13,plotmatrix14)
plotmatrix2 <- rbind(plotmatrix22,plotmatrix21,plotmatrix23,plotmatrix24)


## here also get preseason HAI distribution
hailist1 <- list(NA)
hailist2 <- list(NA)
gmt <- matrix(NA,12,3)

for (u in 1:6){
  a1 <- matrix(NA,3,10)
  for (i in 1:10){
    a1[1,i] <- mean(mcmc2[,i+20*(u-1)]) 
    a1[2,i] <- quantile(mcmc2[,i+20*(u-1)],0.025)
    a1[3,i] <- quantile(mcmc2[,i+20*(u-1)],0.975)
  }    
  hailist1[[u]] <- a1
  ggg <-  rowSums( t((0:9+0.5)*t(mcmc2[,1:10+20*(u-1)]) ) )
  gmt[u,1] <- mean(ggg)
  gmt[u,2:3] <- quantile(ggg,c(0.025,0.975))
  
  a1 <- matrix(NA,3,10)
  for (i in 1:10){
    a1[1,i] <- mean(mcmc2[,i+20*(u-1)+10]) 
    a1[2,i] <- quantile(mcmc2[,i+20*(u-1)+10],0.025)
    a1[3,i] <- quantile(mcmc2[,i+20*(u-1)+10],0.975)
  }    
  hailist2[[u]] <- a1
  ggg <-  rowSums( t((0:9+0.5)*t(mcmc2[,1:10+20*(u-1)+10]) ) )
  gmt[u+6,1] <- mean(ggg)
  gmt[u+6,2:3] <- quantile(ggg,c(0.025,0.975))
}






pdf("/Users/timtsang/SPH Dropbox/Tim Tsang/kiddivax/crossprotection/summary/2020_11_01_figure2.pdf",width=9.5, height=6)
layout(matrix( c(rep(1,8),rep(2,4),rep(3,7),rep(4,5)), nrow=2,byrow=T))



############################################################################################################################################
## panel A
par(mar=c(3,4,2,0))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,7), ylim=c(0,0.6),type="n")

adj1 <- 2.5
adj2 <- 5

axis(1,at=c(0,0.5,1.5,2),labels=c(NA,"Overall","< 1:10",NA),cex.axis=1,lwd.ticks = 0)
axis(1,at=c(0.5,1.5),labels=c(NA),cex.axis=1)
axis(1,at=c(0,0.5,1.5,2)+adj1,labels=c(NA,"Overall","< 1:10",NA),cex.axis=1,lwd.ticks = 0)
axis(1,at=c(0.5,1.5)+adj1,labels=c(NA),cex.axis=1)
axis(1,at=c(0,0.5,1.5,2)+adj2,labels=c(NA,"Overall","< 1:10",NA),cex.axis=1,lwd.ticks = 0)
axis(1,at=c(0.5,1.5)+adj2,labels=c(NA),cex.axis=1)

axis(2,at=0:6*0.1,labels=c("0%","10%","20%","30%","40%","50%","60%"), las=1, pos=-0.05)

points(0:1+0.25,plotmatrix1[1+0:1*6,1],pch=15,col="black")
points(0:1+0.35,plotmatrix1[2+0:1*6,1],pch=16,col="red")
points(0:1+0.45,plotmatrix1[3+0:1*6,1],pch=17,col="blue")
points(0:1+0.55,plotmatrix1[4+0:1*6,1],pch=18,col="orange")
points(0:1+0.65,plotmatrix1[5+0:1*6,1],pch=19,col="purple")
points(0:1+0.75,plotmatrix1[6+0:1*6,1],pch=20,col="brown")

lines(rep(0+0.25,2),plotmatrix1[1+0*6,2:3],col="black")
lines(rep(1+0.25,2),plotmatrix1[1+1*6,2:3],col="black")
for (i in 0:1){
  lines(rep(i+0.35,2),plotmatrix1[2+i*6,2:3],col="red")
  lines(rep(i+0.45,2),plotmatrix1[3+i*6,2:3],col="blue")
  lines(rep(i+0.55,2),plotmatrix1[4+i*6,2:3],col="orange")
  lines(rep(i+0.65,2),plotmatrix1[5+i*6,2:3],col="purple")
  lines(rep(i+0.75,2),plotmatrix1[6+i*6,2:3],col="brown")
}


mtext("Infection probability",side=2,line=2.5)

#mtext("Pre-epidemic HAI titer",side=1,at=2.5,line=2.5,cex=0.7)

mtext("Children",side=3,line=0.5,at=1)
title(main="A", adj=0)


points(0:1+0.25+adj1,plotmatrix1[1+0:1*6,1+3],pch=15,col="black")
points(0:1+0.35+adj1,plotmatrix1[2+0:1*6,1+3],pch=16,col="red")
points(0:1+0.45+adj1,plotmatrix1[3+0:1*6,1+3],pch=17,col="blue")
points(0:1+0.55+adj1,plotmatrix1[4+0:1*6,1+3],pch=18,col="orange")
points(0:1+0.65+adj1,plotmatrix1[5+0:1*6,1+3],pch=19,col="purple")
points(0:1+0.75+adj1,plotmatrix1[6+0:1*6,1+3],pch=20,col="brown")

lines(rep(0+0.25,2)+adj1,plotmatrix1[1+0*6,2:3+3],col="black")
lines(rep(1+0.25,2)+adj1,plotmatrix1[1+1*6,2:3+3],col="black")
for (i in 0:1){
  lines(rep(i+0.35,2)+adj1,plotmatrix1[2+i*6,2:3+3],col="red")
  lines(rep(i+0.45,2)+adj1,plotmatrix1[3+i*6,2:3+3],col="blue")
  lines(rep(i+0.55,2)+adj1,plotmatrix1[4+i*6,2:3+3],col="orange")
  lines(rep(i+0.65,2)+adj1,plotmatrix1[5+i*6,2:3+3],col="purple")
  lines(rep(i+0.75,2)+adj1,plotmatrix1[6+i*6,2:3+3],col="brown")
}



mtext("Younger adults",side=3,line=0.5,at=1+adj1)


points(0:1+0.25+adj2,plotmatrix1[1+0:1*6,1+6],pch=15,col="black")
points(0:1+0.35+adj2,plotmatrix1[2+0:1*6,1+6],pch=16,col="red")
points(0:1+0.45+adj2,plotmatrix1[3+0:1*6,1+6],pch=17,col="blue")
points(0:1+0.55+adj2,plotmatrix1[4+0:1*6,1+6],pch=18,col="orange")
points(0:1+0.65+adj2,plotmatrix1[5+0:1*6,1+6],pch=19,col="purple")
points(0:1+0.75+adj2,plotmatrix1[6+0:1*6,1+6],pch=20,col="brown")

lines(rep(0+0.25,2)+adj2,plotmatrix1[1+0*6,2:3+6],col="black")
lines(rep(1+0.25,2)+adj2,plotmatrix1[1+1*6,2:3+6],col="black")
for (i in 0:1){
  lines(rep(i+0.35,2)+adj2,plotmatrix1[2+i*6,2:3+6],col="red")
  lines(rep(i+0.45,2)+adj2,plotmatrix1[3+i*6,2:3+6],col="blue")
  lines(rep(i+0.55,2)+adj2,plotmatrix1[4+i*6,2:3+6],col="orange")
  lines(rep(i+0.65,2)+adj2,plotmatrix1[5+i*6,2:3+6],col="purple")
  lines(rep(i+0.75,2)+adj2,plotmatrix1[6+i*6,2:3+6],col="brown")
}



legend(5,0.62,c("Epidemic 1, H1N1","Epidemic 2, H3N2","Epidemic 3, H1N1","Epidemic 4, H3N2","Epidemic 5, H1N1","Epidemic 6, H3N2")
       ,pch=c(15:20),lty=1,cex=1,bty="n",col=c("black","red","blue","orange","purple","brown"))


mtext("Older adults",side=3,line=0.5,at=1+adj2)






############################################################################################################################################
## panel B
# panel B data
plotdata <- log2(exp(z1[c(66,68,70,72,74),1:3]))

par(mar=c(3,3,2,0.5))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,5), ylim=c(-2,1),type="n")

axis(1,at=c(-1,0.5,1.5,2.5,3.5,4.5,6),labels=c(NA,"2. H3N2","3. H1N1","4. H3N2","5. H1N1","6. H3N2",NA),cex.axis=1)
axis(2,at=-2:1,labels=2^c(-2:1), las=1, pos=-0.05)

points(0:4+0.5,plotdata[1:5,1],pch=16,col=c("red","blue","orange","purple","brown"))

coltemp <- c("red","blue","orange","purple","brown")
for (i in 0:4){
  lines(rep(i+0.5,2),pmax(-2,plotdata[i+1,2:3]),col=coltemp[i+1])
}

arrows(1.5,-1.9,1.5,-2,length=0.05,col = "blue")

mtext("Risk ratio",side=2,line=2.5)

#mtext("A",side=3,line=0,at=-0.3)
title(main="C", adj=0)
abline(h=0,lty=2)
mtext("Two-fold increase in HAI titer",side=3,line=0.5,cex=0.9)




############################################################################################################################################
## panel C
par(mar=c(3,4,2,0))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,25), ylim=c(0,10),type="n")

# 1,3,5,7,9,11,14,16,18,20,22,24

axis(1,at=c(-1.5,6,19,28),labels = c(NA,"Children","Adults",NA),cex.axis=1)
#axis(2,at=0:10, las=1, pos=-0.5)
#axis(4,at=0:10, las=1, labels = c("<10",5*2^(1:10)), pos=25.5)

axis(2,at=0:10, las=1, labels = c("<10",5*2^(1:10)), pos=-0.5)

rgb1 <- c(0,1,0,1,0.5,0.647)
rgb2 <- c(0,0,0,0.63,0,0.165)
rgb3 <- c(0,0,1,0,0.5,0.165)
for (i in 0:9){
  for (j in 0:5){
    polygon( c(-hailist1[[1+j]][1,rep(1+i,2)],hailist1[[1+j]][1,rep(1+i,2)])+1+2*j,c(0:1,rev(0:1))+i,col=rgb(rgb1[j+1],rgb2[j+1],rgb3[j+1],0.2),border=NA)
    polygon( c(-hailist2[[1+j]][1,rep(1+i,2)],hailist2[[1+j]][1,rep(1+i,2)])+14+2*j,c(0:1,rev(0:1))+i,col=rgb(rgb1[j+1],rgb2[j+1],rgb3[j+1],0.2),border=NA)
  }
}

collist <- c("black","red","blue","orange","purple","brown")

for (i in 0:5){
  lines(1+2*i+c(-1,1),rep(gmt[i+1,1],2),col=collist[i+1],lty=1)
  lines(rep(1+2*i,2),gmt[i+1,2:3],col=collist[i+1],lty=1)
  
  lines(1+2*i+c(-1,1)+13,rep(gmt[i+1+6,1],2),col=collist[i+1],lty=1)
  lines(rep(1+2*i,2)+13,gmt[i+1+6,2:3],col=collist[i+1],lty=1)
}


mtext("Antibody titer",side=2,line=2.25)

#mtext(expression(paste("log"[2]," titer")),side=2,line=1.5)
#mtext(expression(paste("Linear titer")),side=4,line=2.25)
#mtext("Children",side=1,line=2,at=6)
#mtext("Adults",side=1,line=2,at=19)
title(main="B", adj=0)
mtext("Pre-epidemic HAI titer distribution",side=3,line=0.5,cex=0.9)



############################################################################################################################################
## panel D
par(mar=c(3,6,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(2.5,4.5), ylim=c(-2,3),type="n")


adj1 <- 2.5

#axis(1,at=c(0,0.5,1.5,2),labels=c(NA,"Children","Older adults",NA),cex.axis=1,lwd.ticks = 0)
#axis(1,at=c(0.5,1.5),labels=c(NA),cex.axis=1)

axis(1,at=c(0,0.5,1.5,2)+adj1,labels=c(NA,"Children","Older adults",NA),cex.axis=1,lwd.ticks = 0)
axis(1,at=c(0.5,1.5)+adj1,labels=c(NA),cex.axis=1)

axis(2,at=-2:3,labels=2^c(-2:3), las=1, pos=2.45)

coltemp <- c("black","red","blue","orange","purple","brown")

xvec <- c(0.25,0.25+adj1,1.25,1.25+adj1)
yvec1 <- c(1,19,1,19)
yvec2 <- c(1,1,7,7)
for (i in 1:6){
  for (j in c(2,4)){
    points(xvec[j]+(i-1)*0.1,plotmatrix2[yvec1[j]+i-1,yvec2[j]],col=coltemp[i],pch=14+i)
    lines(rep(xvec[j]+(i-1)*0.1,2),pmax(-2,plotmatrix2[yvec1[j]+i-1,yvec2[j]+1:2]),col=coltemp[i])
  }
}

#arrows(1.25+0.5,-1.9,1.25+0.5,-2,col="brown",length=0.05)
arrows(1.25+adj1+0.5,-1.9,1.25+adj1+0.5,-2,col="brown",length=0.05)

mtext("Risk ratio",side=2,line=2.5)

title(main="D", adj=0)
abline(h=0,lty=2)
#mtext("Unadjusted",side=3,line=0.5,at=1,cex=1)
mtext("Relative susceptibility (Ref: Adults)",side=3,line=0.5,at=1+adj1,cex=1)



dev.off()




