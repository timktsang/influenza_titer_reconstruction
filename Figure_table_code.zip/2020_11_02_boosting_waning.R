library(chron)

mcmc <- read.csv("/Users/timtsang/SPH Dropbox/Tim Tsang/kiddivax/crossprotection/program_rcpp/realdata_v67/mcmc_summary_0.499201831175014.csv")

load("/Users/timtsang/SPH Dropbox/Tim Tsang/kiddivax/crossprotection/program_rcpp/realdata_v67/image_0.499201831175014.Rdata")


#### population HAI
test <- read.csv("/Users/timtsang/SPH Dropbox/Tim Tsang/kiddivax/crossprotection/summary/popHAI_v2.csv")
exp(test[1:3,])

#####
##number of infection
quantile(rowSums(tt[[13]]),c(0.5,0.025,0.975))
# without pre-epidemic titer
quantile(rowSums(tt[[13]][,data1[,9]==-1]),c(0.5,0.025,0.975))

# two fold rise
twofold <- pmax((data1[,10]-data1[,9])*(data1[,9]!=-1),(data1[,11]-data1[,10])*(data1[,10]!=-1))

quantile(rowSums(tt[[13]][,twofold==1]),c(0.5,0.025,0.975))

####
# boosting and waning
getmean <- matrix(NA,10000,6)

for (i in 1:10000){
tempvec <- tt[[16]][i,]
tempvec3 <- tt[[15]][i,]
tempvec2 <- tt[[13]][i,]
tempvec <- tempvec[tempvec2==1]
tempvec3 <- tempvec3[tempvec2==1]
getmean[i,1] <- mean(tempvec)
getmean[i,2] <- sd(tempvec)
getmean[i,3] <- mean(tempvec<2)
getmean[i,4] <- sd(tempvec<2)
getmean[i,5] <- mean(1-exp(-tempvec3))
getmean[i,6] <- sd(1-exp(-tempvec3))
}

para_summary(getmean,4,3,0)

# test different
mcmc2 <- tt[[1]][inc,]
## strain change
# h1 children, h3 children, h1 adults, h3 adults
diff <- cbind(mcmc2[,19]-mcmc2[,23],mcmc2[,27]-mcmc2[,31],mcmc2[,19+2]-mcmc2[,23+2],mcmc2[,27+2]-mcmc2[,31+2])
bb1 <- para_summary(diff,4,3,0)
## age
# h1 strange change, h1 no strain change, h3, strain change, h3, no strain change
diff <- cbind(mcmc2[,19]-mcmc2[,21],mcmc2[,23]-mcmc2[,25],mcmc2[,27]-mcmc2[,29],mcmc2[,31]-mcmc2[,33])
bb2 <- para_summary(diff,4,3,0)

diff <- mcmc2[,19+0:7*2]
bb3 <- para_summary(diff,4,3,0)

out <- matrix(NA,9,9)
out[c(2:3,7,8),1:3] <- bb3[c(1,3,5,7),1:3]
out[c(2:3,7,8),1:3+3] <- bb3[1+c(1,3,5,7),1:3]
out[c(4,9),1:3] <- bb1[1:2,1:3]
out[c(4,9),1:3+3] <- bb1[1:2+2,1:3]
out[c(2:3,7:8),1:3+6] <- bb2[,1:3]
out <- round(out,2)

out2 <- matrix(NA,nrow(out),3)
out2[,1] <- paste(out[,1]," (",out[,2],", ",out[,3],")",sep="")
out2[,2] <- paste(out[,4]," (",out[,5],", ",out[,6],")",sep="")
out2[,3] <- paste(out[,7]," (",out[,8],", ",out[,9],")",sep="")
out2[grepl("NA",out2)] <- ""

write.csv(out2,"/Users/timtsang/SPH Dropbox/Tim Tsang/kiddivax/crossprotection/summary/new_table_s3.csv")

############################################################################################################################################
# waning
## strain change
diff <- cbind(mcmc2[,19+1]-mcmc2[,23+1],mcmc2[,27+1]-mcmc2[,31+1],mcmc2[,19+2+1]-mcmc2[,23+2+1],mcmc2[,27+2+1]-mcmc2[,31+2+1])
para_summary(exp(diff),4,3,0)
## age
diff <- cbind(mcmc2[,19+1]-mcmc2[,21+1],mcmc2[,23+1]-mcmc2[,25+1],mcmc2[,27+1]-mcmc2[,29+1],mcmc2[,31+1]-mcmc2[,33+1])
para_summary(exp(-diff),4,3,0)

## compute measure error


error <- z1[1:3,]
error[1,] <- error[1,]*10
error[2:3,] <- 0.25/exp(error[2:3,])


error