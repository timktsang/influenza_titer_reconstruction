## testing code for adding pre-season HAI titer

library(chron)

## the program is to use the imputed infection status to do analysis on correlate

setwd("/Users/timtsang/Dropbox/kiddivax/crossprotection/program_rcpp/realdata_v67")
setwd("Z:/kiddivax/crossprotection/program_rcpp/realdata_v67")

load("/Users/timtsang/Dropbox/kiddivax/crossprotection/program_rcpp/realdata_v67/image_0.499201831175014.Rdata")
load("Z:/kiddivax/crossprotection/program_rcpp/realdata_v67/image_0.499201831175014.Rdata")



########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975),na.rm=T)
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}


impute <- tt[[13]]
imputeHAI <- tt[[17]]
imputeboosting <- tt[[16]]


temp <- data.frame(cbind(data1,impute[1450,],imputeboosting[1450,]))
temp$uid <- paste(temp[,1],temp[,2],sep="-")
names(temp)[c(3,4,5,6,9,12,14,16)] <- c("age","popHAI","popHAI1","popHAI2","HAI","season","inf","boosting")
temp$age[temp$age==2] <- 1


regfunction <- function(varname1,varname2,data){
  a1 <- glm( paste(varname1,"~",varname2),data=data,family=binomial("logit"))
  a2 <- coef(summary(a1))
  if (nrow(a2)>1){
  return(a2[2,1])
  }
  else{
    return(NA)
  }
}

regfunction2 <- function(varname1,varname2,data){
  a1 <- glm( paste(varname1,"~",varname2),data=data,family=binomial("logit"))
  a2 <- coef(summary(a1))
  return(a2[2:3,1])
}

preHAIdist <- tt[[2]][inc,]
################################################################################
## unadjusted
record1 <- matrix(NA,10000,18)


for (ii in 1:100){
  print(ii)
  # first select the data
  index <- sample(1:10000,1)
  temppreHAI <- preHAIdist[index,]
  temp$inf <- impute[index,]
  temp$HAI <- imputeHAI[index,]
  for (j in 1:6){
  temp$popHAI[temp[,3]==0&temp[,12]==j-1] <- temppreHAI[1+20*(j-1)]  *10
  temp$popHAI[temp[,3]==1&temp[,12]==j-1] <- temppreHAI[1+10+20*(j-1)]  *10
  temp$popHAI1[temp[,12]==j-1] <- temppreHAI[1+20*(j-1)]  *10
  temp$popHAI2[temp[,12]==j-1] <- temppreHAI[1+10+20*(j-1)]  *10
  }
  
  for (jj in 1:100){
    temp3 <- temp[sample(1:nrow(temp),replace=T),]
    
    record1[100*(ii-1)+jj,1] <- regfunction("inf","popHAI + as.factor(age) + as.factor(season) + HAI",temp3)
    record1[100*(ii-1)+jj,2] <- regfunction("inf","popHAI1 + as.factor(age) + as.factor(season) + HAI",temp3)
    record1[100*(ii-1)+jj,3] <- regfunction("inf","popHAI2 + as.factor(age) + as.factor(season) + HAI",temp3)
    record1[100*(ii-1)+jj,4] <- regfunction("inf","popHAI + as.factor(age) + as.factor(season) + HAI",temp3[temp$season>=1,])
    record1[100*(ii-1)+jj,5] <- regfunction("inf","popHAI1 + as.factor(age) + as.factor(season) + HAI",temp3[temp$season>=1,])
    record1[100*(ii-1)+jj,6] <- regfunction("inf","popHAI2 + as.factor(age) + as.factor(season) + HAI",temp3[temp$season>=1,])
    
    record1[100*(ii-1)+jj,7] <- regfunction("inf","popHAI  + as.factor(season) + HAI",temp3[temp$age==0,])
    record1[100*(ii-1)+jj,8] <- regfunction("inf","popHAI1 + as.factor(season) + HAI",temp3[temp$age==0,])
    record1[100*(ii-1)+jj,9] <- regfunction("inf","popHAI2  + as.factor(season) + HAI",temp3[temp$age==0,])
    record1[100*(ii-1)+jj,10] <- regfunction("inf","popHAI + as.factor(season) + HAI",temp3[temp$age==0&temp$season>=1,])
    record1[100*(ii-1)+jj,11] <- regfunction("inf","popHAI1  + as.factor(season) + HAI",temp3[temp$age==0&temp$season>=1,])
    record1[100*(ii-1)+jj,12] <- regfunction("inf","popHAI2 + as.factor(season) + HAI",temp3[temp$age==0&temp$season>=1,])
    
    record1[100*(ii-1)+jj,13] <- regfunction("inf","popHAI  + as.factor(season) + HAI",temp3[temp$age==1,])
    record1[100*(ii-1)+jj,14] <- regfunction("inf","popHAI1 + as.factor(season) + HAI",temp3[temp$age==1,])
    record1[100*(ii-1)+jj,15] <- regfunction("inf","popHAI2  + as.factor(season) + HAI",temp3[temp$age==1,])
    record1[100*(ii-1)+jj,16] <- regfunction("inf","popHAI + as.factor(season) + HAI",temp3[temp$age==1&temp$season>=1,])
    record1[100*(ii-1)+jj,17] <- regfunction("inf","popHAI1  + as.factor(season) + HAI",temp3[temp$age==1&temp$season>=1,])
    record1[100*(ii-1)+jj,18] <- regfunction("inf","popHAI2 + as.factor(season) + HAI",temp3[temp$age==1&temp$season>=1,])
  }
}


z1 <- para_summary(record1,4,3,0)

write.csv(z1,"/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/popHAI.csv")

write.csv(z1,"Z:/kiddivax/crossprotection/summary/popHAI.csv")




record1 <- matrix(NA,10000,18)


for (ii in 1:100){
  print(ii)
  # first select the data
  index <- sample(1:10000,1)
  temppreHAI <- preHAIdist[index,]
  temp$inf <- impute[index,]
  temp$HAI <- imputeHAI[index,]
  for (j in 1:6){
    temp$popHAI[temp[,3]==0&temp[,12]==j-1] <- temppreHAI[1+20*(j-1)]  *10
    temp$popHAI[temp[,3]==1&temp[,12]==j-1] <- temppreHAI[1+10+20*(j-1)]  *10
    temp$popHAI1[temp[,12]==j-1] <- temppreHAI[1+20*(j-1)]  *10
    temp$popHAI2[temp[,12]==j-1] <- temppreHAI[1+10+20*(j-1)]  *10
  }
  
  for (jj in 1:100){
    temp3 <- temp[sample(1:nrow(temp),replace=T),]
    
    record1[100*(ii-1)+jj,1] <- regfunction("inf","popHAI + as.factor(age)  + HAI",temp3)
    record1[100*(ii-1)+jj,2] <- regfunction("inf","popHAI1 + as.factor(age)  + HAI",temp3)
    record1[100*(ii-1)+jj,3] <- regfunction("inf","popHAI2 + as.factor(age)  + HAI",temp3)
    record1[100*(ii-1)+jj,4] <- regfunction("inf","popHAI + as.factor(age)  + HAI",temp3[temp$season>=1,])
    record1[100*(ii-1)+jj,5] <- regfunction("inf","popHAI1 + as.factor(age)  + HAI",temp3[temp$season>=1,])
    record1[100*(ii-1)+jj,6] <- regfunction("inf","popHAI2 + as.factor(age)  + HAI",temp3[temp$season>=1,])
    
    record1[100*(ii-1)+jj,7] <- regfunction("inf","popHAI   + HAI",temp3[temp$age==0,])
    record1[100*(ii-1)+jj,8] <- regfunction("inf","popHAI1  + HAI",temp3[temp$age==0,])
    record1[100*(ii-1)+jj,9] <- regfunction("inf","popHAI2   + HAI",temp3[temp$age==0,])
    record1[100*(ii-1)+jj,10] <- regfunction("inf","popHAI  + HAI",temp3[temp$age==0&temp$season>=1,])
    record1[100*(ii-1)+jj,11] <- regfunction("inf","popHAI1   + HAI",temp3[temp$age==0&temp$season>=1,])
    record1[100*(ii-1)+jj,12] <- regfunction("inf","popHAI2  + HAI",temp3[temp$age==0&temp$season>=1,])
    
    record1[100*(ii-1)+jj,13] <- regfunction("inf","popHAI   + HAI",temp3[temp$age==1,])
    record1[100*(ii-1)+jj,14] <- regfunction("inf","popHAI1 + HAI",temp3[temp$age==1,])
    record1[100*(ii-1)+jj,15] <- regfunction("inf","popHAI2  + HAI",temp3[temp$age==1,])
    record1[100*(ii-1)+jj,16] <- regfunction("inf","popHAI  + HAI",temp3[temp$age==1&temp$season>=1,])
    record1[100*(ii-1)+jj,17] <- regfunction("inf","popHAI1   + HAI",temp3[temp$age==1&temp$season>=1,])
    record1[100*(ii-1)+jj,18] <- regfunction("inf","popHAI2  + HAI",temp3[temp$age==1&temp$season>=1,])
  }
}


z1 <- para_summary(record1,4,3,0)

write.csv(z1,"/Users/timtsang/Dropbox/kiddivax/crossprotection/summary/popHAI_v2.csv")

write.csv(z1,"Z:/kiddivax/crossprotection/summary/popHAI_v2.csv")

