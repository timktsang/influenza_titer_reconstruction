
setwd("/Users/timtsang/Dropbox/kiddivax/crossprotection/program_rcpp/realdata_v67_sim")

#setwd("/Users/timtsang/Dropbox2/Dropbox/kiddivax/crossprotection/program_rcpp/realdata/v12")

rawlist <- list.files(pattern="*.csv")
rawlist1 <- rawlist[grepl("summary_",rawlist)]
rawlist2 <- rawlist[grepl("summary2_",rawlist)]

int_para <-  c(0.2,
               3.5,3.0,
               1,1.5,
               3.5,3.0,
               1,1.5,
               1,1,1,1,
               1,1,1,1,
               0.25,0.1,0.1,0.4,0.2,0.2,
               0.4,0.2,0.2,
               0.4,0.2,0.2,
               0.4,0.2,0.2)

#int_para[2:9] <- int_para[2:9]*10
#int_para[10:17] <- int_para[2:9]/10

# children, adults
int_para2 <- c(0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005) 

int_para <- as.vector(as.matrix(read.csv("para1.csv"))[,2])
int_para2 <- as.vector(as.matrix(read.csv("para2.csv"))[,2])
#int_para[30:32]<- 0.25

nsim <- 50
tt1 <- tt2 <- matrix(NA,nsim,length(int_para))
tt12 <- tt22 <- matrix(NA,nsim,length(int_para2))

for (i in 1:nsim){
temp <- read.csv(rawlist1[i])  
tt1[i,] <- temp[,2]
tt2[i,] <- 1*(temp[,3] <= int_para & temp[,4] >= int_para)

temp <- read.csv(rawlist2[i])  
tt12[i,] <- temp[,2]
tt22[i,] <- 1*(temp[,3] <= int_para2 & temp[,4] >= int_para2)
}

summary(tt1)
summary(tt2)

summary(tt12)
summary(tt22)

test <- read.csv("/Users/timtsang/Dropbox2/Dropbox/kiddivax/multiple_strain/program_rcpp/simulation2/mcmc_result_0.0584603897295892.csv")



########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}

para_summary(test[50000+5*1:10000,2:ncol(test)],4,3,1)