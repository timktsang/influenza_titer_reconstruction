
rm(list = ls())

library(Rcpp)
library(RcppParallel)


########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}


########

#season <- 1
#setwd(paste("/Users/timtsang/Dropbox/kiddivax/crossprotection/program_rcpp/realdata_v44_s",season,sep=""))
#setwd(paste("/Users/timtsang/OneDrive/realdata_v44_s",season,sep=""))
#setwd(paste("T:/kiddivax/crossprotection/realdata_v44_s",season,sep=""))

#setwd("/Users/timtsang/Dropbox/kiddivax/crossprotection/program_rcpp/realdata_v65_sim_uf")
#setwd("Z:/kiddivax/crossprotection/program_rcpp/realdata_v65_sim_uf")
########################################################################################################################################################################
dataS1 <- cbind(cbind(read.csv("2019_12_09_dataS1.csv"),0,0))
dataS2 <- cbind(cbind(read.csv("2019_12_09_dataS2.csv"),1,1))
dataS3 <- cbind(cbind(read.csv("2019_12_09_dataS3.csv"),2,0))
dataS4 <- cbind(cbind(read.csv("2019_12_09_dataS4.csv"),3,1))
dataS5 <- cbind(cbind(read.csv("2019_12_09_dataS5.csv"),4,0))
dataS6 <- cbind(cbind(read.csv("2019_12_09_dataS6.csv"),5,1))

names(dataS1) <- NA
names(dataS2) <- NA
names(dataS3) <- NA
names(dataS4) <- NA
names(dataS5) <- NA
names(dataS6) <- NA

data <- rbind(dataS1,dataS2,dataS3,dataS4,dataS5,dataS6)

## missing age
data <- data[data[,3]!=-1,]

## here add the parameter for strain
data[,14] <- data[,12]
data[data[,12]==0,14] <- 0
data[data[,12]==1,14] <- 3
data[data[,12]==2,14] <- 1
data[data[,12]==3,14] <- 2
data[data[,12]==4,14] <- 1
data[data[,12]==5,14] <- 3
## here test subset first
#data <- data[data[,12]<=3,]




########################################################################################################################################################################

ILI <- read.csv("ILILAB_2019_04_25.csv",header=F)
ILI[ILI==0] <- 0.00000000001

## here the proxy is starting from 2008/01/01, data is starting from 2008/07/01
ILI <- ILI[-c(1:182),]
#ILI[,1] <- mean(ILI[,1])
#ILI[,2] <- mean(ILI[,2])


## each of the time need to -14 to represent the boosting delay
data[,4:8] <- data[,4:8]-14
data[data==-15] <- -1

## try simple format, i.e. gamma with second parameter = 1, beta with second parameter = 1
## model parameter
# 1-18  1.random,  2.1-fold, 3-2fold error*6
# 19-42     1-4 children, adult, older adult boost and waning
# 43-63     infection para      
# 64-75    HAI protection
## first create a function for simulation

int_para <-  c(0.005,rep(0.6,17),rep(c(3.5,0.5),12),rep(c(0.4,0.2,0.2),7),rep(-0.1,12))
  
# children, adults
int_para2 <- c(0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005) 

int_para <- as.vector(as.matrix(read.csv("para1.csv"))[,2])
int_para2 <- as.vector(as.matrix(read.csv("para2.csv"))[,2])

for (i in 1:12){
int_para2[10*(i-1)+1:10] <- int_para2[10*(i-1)+1:10]/sum(int_para2[10*(i-1)+1:10])
}


sourceCpp("crossprotection.cpp")

########################################################################################################################################################################
########### here is inputing the data
data1 <- as.matrix(data)
ILI <- as.matrix(ILI)
########################################################################################################################################################################


  
t <- sim_data(data1,ILI,int_para,int_para2)

input1 <- t[[1]]
input2 <- t[[2]]
input3 <- t[[3]]

#write.csv(input1,"input1.csv",row.names = F)
#write.csv(input2,"input2.csv",row.names = F)
#write.csv(input3,"input3.csv",row.names = F)

blankmatrix <- matrix(0,nrow(input1),2)

########################################################################################################################################################################
## for testing
test <- loglik(input1,input2,input3,ILI,int_para,int_para2,1,1,1,0,blankmatrix)
sum(test[[1]])+sum(test[[2]])+sum(test[[3]])

########################################################################################################################################################################
## here is the testing session

test2 <- all_update(input1,input2,input3,ILI,int_para,int_para2,test[[1]],test[[2]],test[[3]])
#test2[[7]][test2[[7]][,1]!=0,]
sum(test2[[3]])+sum(test2[[4]])+sum(test2[[5]])

test3 <- loglik(test2[[1]],input2,test2[[2]],ILI,int_para,int_para2,1,1,1,0,blankmatrix)
sum(test3[[1]])+sum(test3[[2]])+sum(test3[[3]])


test2 <- add_remove_infection(input1,input2,input3,ILI,int_para,int_para2,test[[1]],test[[2]],test[[3]])
test2[[7]][test2[[7]][,1]!=0,]
sum(test2[[3]])+sum(test2[[4]])+sum(test2[[5]])

test3 <- loglik(test2[[1]],input2,test2[[2]],ILI,int_para,int_para2,1,1,1,0,blankmatrix)
sum(test3[[1]])+sum(test3[[2]])+sum(test3[[3]])
sum(test2[[2]][,4]-input3[,4])


########################################################################################################################################################################
## here to set to real data
#input2 <- data1
#input2 <- as.matrix(read.csv("input2.csv"))
#input1 <- as.matrix(read.csv("input1.csv"))
#input3 <- as.matrix(read.csv("input3.csv"))
####################################################################################

sigma <- abs(int_para)/10
move <- rep(1,length(int_para))


para <- int_para
for (i in 1:length(para)){
  para[i] <- runif(1,para[i]-4*abs(para[i])/10,para[i]+4*abs(para[i])/10)  
} 


int_para3 <- rep(1,12)
sigma3 <- int_para3/10

para2 <- rep(0.1,120)


#h1para <- c(2,3,6:11)
#h3para <- c(4,5,12:17)

#stoppara <- c((season%%2==0)*h1para,(season%%2==1)*h3para,(season!=1)*18:20,setdiff(21:38,1:3+17+3*season))
#move[stoppara] <- 0
#para[stoppara] <- 0.01
  
move[c(4:18,35:42,64:65,67,69,71,73,75)] <- 0
int_para[64:65] <- 0
#para[c(4,5,8,9,12:13,16:17)] <- int_para[c(4,5,8,9,12:13,16:17)]
#table(floor(input1_org[t[[1]][,3]<1,9]))

#table(floor(input1_org[t[[2]][,9]!=-1&t[[1]][,3]<1,9]))/sum(table(floor(input1_org[t[[2]][,9]!=-1&t[[1]][,3]<1,9])))


#sourceCpp("crossprotection.cpp")

#save.image("image.Rdata")


## season paralist to increase the speed
paraseason <- c(rep(0,42),rep(1,6),rep(2:6,each=3),rep(1:6,each=2))

aaaaa1 <- Sys.time()
tt <- mcmc(input1,input2,input3,ILI,200000,int_para,para2,int_para3,paraseason,move,sigma,sigma3)
aaaaa2 <- Sys.time()
print(aaaaa2-aaaaa1)
sum(tt[[12]][tt[[12]][,4]==1,5]==0)

## for testing
test <- loglik(tt[[10]],tt[[11]],tt[[12]],ILI,int_para,int_para2,1,1,1,0,blankmatrix)
sum(test[[1]])+sum(test[[2]])+sum(test[[3]])

#para_summary(tt[[2]],4,3,1)

#table(floor(tt[[8]][t[[2]][,9]!=-1&t[[1]][,3]<1,9]))/sum(table(floor(tt[[8]][t[[2]][,9]!=-1&t[[1]][,3]<1,9])))

#table(floor(tt[[8]][t[[1]][,3]<1,9]))/sum(table(floor(tt[[8]][t[[1]][,3]<1,9])))



table(input3[,4])


id <- runif(1,0,1)
inc <- 100000+1:10000*10
#inc <- 1:2000
z1 <- para_summary((tt[[1]][inc,]),4,4,0)
write.csv(z1,paste("mcmc_summary_",id,".csv",sep=""))

z2 <- para_summary((tt[[2]][inc,]),4,4,0)
write.csv(z2,paste("mcmc_summary2_",id,".csv",sep=""))

z3 <- para_summary((tt[[3]][inc,]),4,4,0)

write.csv(input1,paste("input1_",id,".csv",sep=""))
write.csv(input2,paste("input2_",id,".csv",sep=""))
write.csv(input3,paste("input3_",id,".csv",sep=""))

a1 <- tt[[13]]
save(a1,file=paste("inf_status_",id,".Rdata",sep=""))

#save.image(paste("image_",id,".Rdata",sep=""))





asdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdgasdfasgsdg
sourceCpp("crossprotection.cpp")
set1 <- input2[,9]!=-1
set2 <- input2[,11]!=-1
out41 <- matrix(NA,3,9)
agelist <- list(c(0,1,2),0,c(1,2))

countfunction <- function(input21,set1,set2,set3){
  recvec <- matrix(NA,1,27)
  agelist <- list(c(0,1,2),0,c(1,2))
  for (i in 1:3){ 
    recvec[1,1+9*(i-1)] <- sum(input21[,10]-input21[,9]>=4&input21[,3]%in%agelist[[i]]&set1&set3) + sum(input21[,11]-input21[,10]>=4&input21[,3]%in%agelist[[i]]&set2&set3)
    recvec[1,2+9*(i-1)] <- sum(input21[,10]-input21[,9]==3&input21[,3]%in%agelist[[i]]&set1&set3) + sum(input21[,11]-input21[,10]==3&input21[,3]%in%agelist[[i]]&set2&set3)
    recvec[1,3+9*(i-1)] <- sum(input21[,10]-input21[,9]==2&input21[,3]%in%agelist[[i]]&set1&set3) + sum(input21[,11]-input21[,10]==2&input21[,3]%in%agelist[[i]]&set2&set3)
    recvec[1,4+9*(i-1)] <- sum(input21[,10]-input21[,9]==1&input21[,3]%in%agelist[[i]]&set1&set3) + sum(input21[,11]-input21[,10]==1&input21[,3]%in%agelist[[i]]&set2&set3)
    recvec[1,5+9*(i-1)] <- sum(input21[,10]-input21[,9]==0&input21[,3]%in%agelist[[i]]&set1&set3) + sum(input21[,11]-input21[,10]==0&input21[,3]%in%agelist[[i]]&set2&set3)
    recvec[1,6+9*(i-1)] <- sum(input21[,10]-input21[,9]==-1&input21[,3]%in%agelist[[i]]&set1&set3) + sum(input21[,11]-input21[,10]==-1&input21[,3]%in%agelist[[i]]&set2&set3)
    recvec[1,7+9*(i-1)] <- sum(input21[,10]-input21[,9]==-2&input21[,3]%in%agelist[[i]]&set1&set3) + sum(input21[,11]-input21[,10]==-2&input21[,3]%in%agelist[[i]]&set2&set3)
    recvec[1,8+9*(i-1)] <- sum(input21[,10]-input21[,9]==-3&input21[,3]%in%agelist[[i]]&set1&set3) + sum(input21[,11]-input21[,10]==-3&input21[,3]%in%agelist[[i]]&set2&set3)
    recvec[1,9+9*(i-1)] <- sum(input21[,10]-input21[,9]<= -4&input21[,3]%in%agelist[[i]]&set1&set3) + sum(input21[,11]-input21[,10]<= -4&input21[,3]%in%agelist[[i]]&set2&set3)
  }  
  return(recvec)
}

seasonlist <- list(0:5,0,1,2,3,4,5)
reclist <- list(matrix(NA,1000,27),matrix(NA,1000,27),matrix(NA,1000,27),matrix(NA,1000,27),matrix(NA,1000,27),matrix(NA,1000,27),matrix(NA,1000,27))
recreallist <- list(matrix(NA,1000,27),matrix(NA,1000,27),matrix(NA,1000,27),matrix(NA,1000,27),matrix(NA,1000,27),matrix(NA,1000,27),matrix(NA,1000,27))
for (uu in 1:1000){
  if (uu%%100==0){
    print(uu)
  }
  index <- sample(1:10000,1)
  inputpara <- a1[index,]
  tttt <- sim_data(input2,ILI,inputpara,a2[index,])
  input11 <- tttt[[1]]
  input21 <- data.frame(tttt[[2]])
  input31 <- tttt[[3]]
  for (kk in 1:7){
    set3 <- input31[,4]==1&input2[,12]%in%seasonlist[[kk]] #&(input21[,11]>0|input21[,10]>0&input21[,9]>0)
    # simulation data
    reclist[[kk]][uu,] <- countfunction(input21,set1,set2,set3)
    # realdata
    set3 <- tt[[13]][index,]&input2[,12]%in%seasonlist[[kk]] #&(input2[,11]>0|input2[,10]>0&input2[,9]>0)
    recreallist[[kk]][uu,] <- countfunction(input2,set1,set2,set3)
  }
}

reclist_p <- reclist
recreallist_p <- recreallist
## use the recreallist to construct the proportion
for (kk in 1:7){
  for (i in 1:3){
    recreallist_p[[kk]][,1:9+9*(i-1)] <- recreallist[[kk]][,1:9+9*(i-1)]/rowSums(recreallist[[kk]][,1:9+9*(i-1)])
    reclist_p[[kk]][,1:9+9*(i-1)] <- reclist[[kk]][,1:9+9*(i-1)]/rowSums(reclist[[kk]][,1:9+9*(i-1)])
  }
}

obs_p <- cbind(colMeans(recreallist_p[[1]]),colMeans(recreallist_p[[2]]),colMeans(recreallist_p[[3]]),
               colMeans(recreallist_p[[4]]),colMeans(recreallist_p[[5]]),colMeans(recreallist_p[[6]]),colMeans(recreallist_p[[7]]))

sim_p_mean <- cbind(colMeans(reclist_p[[1]]),colMeans(reclist_p[[2]]),colMeans(reclist_p[[3]]),
                    colMeans(reclist_p[[4]]),colMeans(reclist_p[[5]]),colMeans(reclist_p[[6]]),colMeans(reclist_p[[7]]))
# var
sim_p_var1 <- sim_p_mean
for (j in 1:7){
  for (i in 1:27){
    sim_p_var1[i,j] <- var(reclist_p[[j]][,i]) 
  }  
}


reclist_p_var <- reclist_p

library(DescTools)

for (uu in 1:1000){
  if (uu%%100==0){
    print(uu)
  }
  for (kk in 1:7){
    for (i in 1:3){
      temp <-  MultinomCI(reclist[[kk]][uu,1:9+9*(i-1)], conf.level=0.95)
      reclist_p_var[[kk]][uu,1:9+9*(i-1)] <- (pmax(temp[,1]-temp[,2],temp[,3]-temp[,1])/1.96)^2
    }  
  }
}

sim_p_var2 <- cbind(colMeans(reclist_p_var[[1]]),colMeans(reclist_p_var[[2]]),colMeans(reclist_p_var[[3]]),
                    colMeans(reclist_p_var[[4]]),colMeans(reclist_p_var[[5]]),colMeans(reclist_p_var[[6]]),colMeans(reclist_p_var[[7]]))

outlist <- list(NA)
for (kk in 1:7){
  tempmat <- matrix(NA,27,4)
  tempmat[,4] <- obs_p[,kk]
  tempmat[,1] <- sim_p_mean[,kk]    
  var <- sim_p_var1[,kk] + sim_p_var2[,kk]
  tempmat[,2] <- tempmat[,1] - 1.96*sqrt(var)
  tempmat[,3] <- tempmat[,1] + 1.96*sqrt(var)
  outlist[[kk]] <- tempmat
}



write.csv(outlist,paste("modeladeq_",id,".csv",sep=""))
