
rm(list = ls())

library(Rcpp)
library(RcppParallel)


########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}


########

## set link to the file 
setwd("/Users/timtsang/SPH Dropbox/Tim Tsang/kiddivax/crossprotection/program_rcpp/code_demo")
## read HAI titer data
data <- read.csv("data_demo.csv")

## to reduce the run time, sample a subset of data
data <- data[sample(1:nrow(data),500),]

########################################################################################################################################################################

## read influenza proxy data
ILI <- read.csv("ILILAB_2019_04_25.csv",header=F)
ILI[ILI==0] <- 0.00000000001

## here the proxy is starting from 2008/01/01, data is starting from 2008/07/01
ILI <- ILI[-c(1:182),]

## model parameter
# 1. probability that measurement went wrong so that the observed HAI titer was a random value in between 0 to 9
# 2. parameter for one side error for H1N1
# 3. parameter for one side error for H3N2
# 4-18. un-used parameter, save for future change
# Boosting and waning for H1N1 with strain change (Epidemic 1)
# 19. mean boosting for children
# 20. mean waning for children
# 21. mean boosting for adults
# 22. mean waning for adults
# Boosting and waning for H1N1 without strain change (Epidemic 3 and 5)
# 23. mean boosting for children
# 24. mean waning for children
# 25. mean boosting for adults
# 26. mean waning for adults
# Boosting and waning for H3N2 with strain change (Epidemic 4)
# 27. mean boosting for children
# 28. mean waning for children
# 29. mean boosting for adults
# 30. mean waning for adults
# Boosting and waning for H3N2 without strain change (Epidemic 2 and 6)
# 31. mean boosting for children
# 32. mean waning for children
# 33. mean boosting for adults
# 34. mean waning for adults
# 35-42. un-used parameter, save for future change
# Parameters related to 1) H1N1
# 43. children before change point 
# 44. adults before change point
# 45. older adults before change point
# 46. children in after change point 
# 47. adults in after change point
# 48. older adults after change point
# Parameters related to 2) H3N2
# 49. children 
# 50. adults 
# 51. older adults 
# Parameters related to 3) H1N1
# 52. children 
# 53. adults 
# 54. older adults 
# Parameters related to 4) H3N2
# 55. children 
# 56. adults 
# 57. older adults 
# Parameters related to 5) H1N1
# 58. children 
# 59. adults 
# 60. older adults 
# Parameters related to 6) H3N2
# 61. children 
# 62. adults 
# 63. older adults 
# 64, 65, 67, 69, 71, 73, 75 un-used parameter, save for future change
# 66. Parameters related to 2) H3N2, protection of HAI titers
# 68. Parameters related to 3) H1N1, protection of HAI titers
# 70. Parameters related to 4) H3N2, protection of HAI titers
# 72. Parameters related to 5) H1N1, protection of HAI titers
# 74. Parameters related to 6) H3N2, protection of HAI titers

# HAI titer model parameter
int_para <-  c(0.005,rep(0.6,17),rep(c(3.5,0.5),12),rep(c(0.4,0.2,0.2),7),rep(-0.1,12))
  
# parameter for thd distribution of pre-epidemic HAI titer (SI section 2.7)
int_para2 <- c(0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005,
               0.82,0.08,0.065,0.005,0.005,0.005,0.005,0.005,0.005,0.005,               
               0.87,0.04,0.04,0.015,0.01,0.005,0.005,0.005,0.005,0.005) 

# input for a parameter fitted to real data
int_para <- as.vector(as.matrix(read.csv("para1.csv"))[,2])
int_para2 <- as.vector(as.matrix(read.csv("para2.csv"))[,2])

for (i in 1:12){
int_para2[10*(i-1)+1:10] <- int_para2[10*(i-1)+1:10]/sum(int_para2[10*(i-1)+1:10])
}


sourceCpp("crossprotection.cpp")

########################################################################################################################################################################
########### here is inputing the data
data1 <- as.matrix(data)
ILI <- as.matrix(ILI)
########################################################################################################################################################################

t <- sim_data(data1,ILI,int_para,int_para2)

# the augmented data for true HAI titer
input1 <- t[[1]]
# the observed data 
input2 <- t[[2]]
#input3_out <- data.frame(input3)
input3 <- t[[3]]

## define input1 to 3 # not necessary for running the model
# the augmented data for true HAI titer
#input1_out <- data.frame(input1)
#names(input1_out) <- c("hhID","member","age_group","start_time","end_time","time1","time2","time3","HAI_titer_1","HAI_titer_2","HAI_titer3","season","flu.type","boosting.type")
# the observed data 
#input2_out <- data.frame(input2)
#names(input2_out) <- c("hhID","member","age_group","start_time","end_time","time1","time2","time3","HAI_titer_1","HAI_titer_2","HAI_titer3","season","flu.type","boosting.type")
# the augmented data for unobserved boost and waning paramter, infection, infection time
#input3_out <- data.frame(input3)
#names(input3_out) <- c("hhID","member","age_group","inf_status","inf_time","boosting","waning","NA","NA","NA")

## the MCMC chain sigma for parameter
sigma <- abs(int_para)/10
## to indicate if the parameter is included in the model, set those unused parameter to 0
move <- rep(1,length(int_para))

para <- int_para
for (i in 1:length(para)){
  para[i] <- runif(1,para[i]-4*abs(para[i])/10,para[i]+4*abs(para[i])/10)  
} 

int_para3 <- rep(1,12)
sigma3 <- int_para3/10

para2 <- rep(0.1,120)

move[c(4:18,35:42,64:65,67,69,71,73,75)] <- 0
int_para[64:65] <- 0

## season paralist to increase the speed
## a vector to indicte if the parameter belong to which season
paraseason <- c(rep(0,42),rep(1,6),rep(2:6,each=3),rep(1:6,each=2))

aaaaa1 <- Sys.time()
tt <- mcmc(input1,input2,input3,ILI,200000,int_para,para2,int_para3,paraseason,move,sigma,sigma3)
aaaaa2 <- Sys.time()
print(aaaaa2-aaaaa1)

## output fitting posterior samples
id <- runif(1,0,1)
inc <- 100000+1:10000*10

z1 <- para_summary((tt[[1]][inc,]),4,4,0)
write.csv(z1,paste("mcmc_summary_",id,".csv",sep=""))

z2 <- para_summary((tt[[2]][inc,]),4,4,0)
write.csv(z2,paste("mcmc_summary2_",id,".csv",sep=""))

z3 <- para_summary((tt[[3]][inc,]),4,4,0)


#save.image(paste("image_",id,".Rdata",sep=""))



